# Complete Kiln Jaeger

A rigid mechanical character modeled, textured, rigged and animated in Kiln from the approved reference. Slate-gray armor, yellow visor, chest reactor, articulated hands, forearm blades, independent shoulder cannons and back thrusters.

**Current delivery: v4, with texture-based identification and fastener recesses, plus sixteen animations.** The next project is the separate Jaeger Demo. Its implementation plan and copy-ready goal are in [the scene spec](docs/jaeger-demo-spec.md) and [implementation goal](docs/implementation-goal.md).

## Open or download

- Complete model: [jaeger-complete-v4.glb](output/jaeger-complete-v4.glb), 3,771,340 bytes.
- Portable project package: [jaeger-complete-v4.zip](output/jaeger-complete-v4.zip).
- Native editable bundles: [ground/combat](output/jaeger-ground-combat-v4-editable.zip) and [boost/weapons](output/jaeger-boost-weapons-v4-editable.zip).
- Approved reference: [approved-mech.png](reference/approved-mech.png).
- Editable modules: parts/; complete definition: jaeger.kiln.js.

[Open the complete v4 model in the local Kiln viewer](http://127.0.0.1:4329/?collection=project&asset=a_3b3f7e17e46f4e08a03d867dcdd74d82&revision=r_7507a38b0f5245ad98935203cf9b5c7b)

Select an Animation. Drag to orbit and scroll to zoom. Walking and flight move through space, so zoom out. This asset viewer loops clips; the future scene must implement controls and root-motion accumulation.

To restart the preview from this configured workspace:

~~~powershell
node kiln.mjs view --collection project --asset a_3b3f7e17e46f4e08a03d867dcdd74d82 --revision r_7507a38b0f5245ad98935203cf9b5c7b --port 4329
~~~

The GLB embeds geometry, materials, eight PNGs and animations. It loads independently in ordinary glTF 2.0 software. Kiln source is separate.

## What changed in v4

The 2-03 mark and four tiny chips are painted into the chest texture. Eleven bolt sockets use one shared 64px color/normal/metallic-roughness set; their heads retain real geometry. All are authored inside Kiln source using owned procedural textures and deterministic pixel painting. No Blender or runtime shader is needed.

| Metric | V3 | V4 |
| --- | ---: | ---: |
| Triangles | 74,840 | 71,620 |
| Mesh objects | 483 | 470 |
| Materials | 14 | 14 |
| GLB bytes | 3,790,356 | 3,771,340 |
| Embedded PNGs | 4 | 8 |
| Animation clips / tracks | 16 / 359 | 16 / 359 |

The added PNG payload is 18,642 bytes. The original four 256px PBR maps are unchanged. The new chest map is 512px; the three fastener maps are 64px. Total decoded RGBA pixels use about 2.05 MiB before mipmaps.

The full retained mesh shapes/normals, node transforms/parents and animation keyframes are unchanged from v3. The corrected thumbs, rear armor and leg panels remain. See [texture optimization](docs/texture-optimization.md) for measured savings and further candidates.

**Ready for scene integration, with runtime batching still required.** These changes remove thirteen objects, but 470 mesh submissions remain. The demo spec puts measured hero optimization before environment polish. Metadata slimming is being implemented as a separate Kiln export-profile PR; it is not a rendering/FPS optimization and is not yet a released engine feature.

## Motion and integration

Idle, Walk, TurnLeft, TurnRight, SlashLeft, SlashRight, SlashCombo, OverheadStrike, CannonAim, CannonFire, JumpPrepare, Takeoff, Hover, ForwardFlight, Landing, HitRecovery.

Connected rigid pivots animate solid parts. There are 93 named joints, with muzzle, blade, palm, foot and thruster sockets. Cannons follow their independent backpack mounts. The model is approximately 8.12 m tall, in metres, +X forward and +Y up.

Read [motion-design.md](motion-design.md) before integration. The demo still needs the state machine, collision-safe movement, stop/flight transition handling, VFX and audio. No game-scene behavior is implied by the exported clips alone.

## Authoring and reproducible packaging

The current Kiln source execution limit is 256 tracks per build. Two native batches preserve all 359 tracks:

| Batch | Program reference | Tracks | Native revision |
| --- | --- | ---: | --- |
| Ground/combat | p_83b045764971 | 154 | r_055890f4cce142ccb5ba4c8e2d88753d |
| Boost/weapons | p_c50bf8dd6b42 | 205 | r_340376dea4b3478db420ebcaea6087fe |

Ground/combat asset: a_4a2ff44d4ebe49f7a878000b7674a421. Boost/weapons asset: a_f7fc9116d8e545bdb38f4669e70227eb. Each v4 revision is an immutable child of its v3 source revision. The combined viewer import is correctly marked GLB-only; its source is in the two native bundles and the portable project package.

The packaging script combines channels on an asserted identical graph while preserving geometry and animation-accessor bytes. Its provenance now uses logical batch IDs and content hashes, with no local paths. A rebuild in a different directory reproduces the complete GLB hash exactly.

~~~powershell
node scripts/rebuild-jaeger.mjs output/my-rebuild
~~~

Run in a configured Kiln workspace with a fresh output directory. The loader resolves Three.js from THREE_ROOT, local dependencies or the workspace runtime; actual texture verification also requires Sharp. Generation tools and keys are not required by a viewer.

## Verified evidence and limits

Complete v4 SHA-256: **14155efa3ebef47839b70632c0b185557d743abcb99d00e2fa093ba75e3553e0**.

- 226 export/material/motion checks pass: 470 closed outward meshes, 564 nodes, 93 named joints, eight decoded PNGs, 192 textured UV sets and 26 map bindings. All sixteen clips are sampled over 1,335 frames.
- The independent v3/v4 comparison confirms exactly thirteen expected removals; all retained geometry/normals/transforms/parents, original texture pixels and 359 animation tracks match.
- GPU views verify front/angled/context finish, the isolated rear chest without repeated text, and close-up recessed fasteners. The v4 model also loads in the local viewer.
- A complete rebuild in output/rebuilt-v4-portable-proof reproduces the delivery hash.
- Previous sampled leg clearances remain applicable because those meshes/transforms are unchanged. Existing contact residuals and loft QA limits remain documented in the verification receipts.

Evidence: output/jaeger-complete-v4.glb.verification.json, output/jaeger-complete-v4.glb.texture-comparison.json, output/jaeger-complete-v4.glb.packaging.json, output/texture-v4-delivery-0.png and its JSON receipt; native save/import receipts; output/rebuilt-v4-portable-proof/.

The native saves retain 32 LOFT_SELF_INTERSECTION_UNCHECKED advisories. Sampled checks do not establish continuous collision clearance, target-scene FPS, real-phone performance, or final artistic approval. Those belong to the demo's explicit validation and playtest milestones.

V2 and v3 artifacts and immutable source revisions remain available. Their historical verification is preserved in KILN_PROGRESS.md and output/README-v3.md.
