// Ray-test visible panel faces against their underlying armor in the actual GLB.
import {readFile,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {loadGlbNode} from './load-glb-node.mjs';
const runtime=JSON.parse(await readFile('.kiln/workspace.json','utf8')).runtime;
const THREE=await import(pathToFileURL(resolve(runtime,'node_modules/three/build/three.module.js')).href);
const file=process.argv[2];if(!file)throw new Error('Provide a GLB');
const {gltf}=await loadGlbNode(file);
gltf.scene.updateMatrixWorld(true);
const results=[];
for(const side of ['R','L'])for(const [part,panel,base,range]of [
  ['thigh','ThighFrontPanel','ThighArmor',[-1.44,-.28,-.27,.27]],
  ['thigh-inset','ThighInset','ThighFrontPanel',[-.76,-.37,-.12,.18]],
  ['shin','ShinFrontPlate','ShinArmor',[-1.55,-.28,-.24,.24]],
  ['shin-ridge','ShinCenterRidge','ShinFrontPlate',[-1.50,-.32,-.03,.035]],
]){
  const overlay=gltf.scene.getObjectByName('Mesh_'+panel+'_'+side),under=gltf.scene.getObjectByName('Mesh_'+base+'_'+side);
  if(!overlay||!under)throw new Error('Missing '+part+'_'+side);
  const frame=overlay.parent;
  const direction=new THREE.Vector3(-1,0,0).transformDirection(frame.matrixWorld),ray=new THREE.Raycaster();
  let samples=0,minClearance=Infinity,pierced=0,worst=null;
  for(let iy=0;iy<=80;iy++)for(let iz=0;iz<=40;iz++){
    const y=range[0]+(range[1]-range[0])*iy/80,z=range[2]+(range[3]-range[2])*iz/40;
    ray.set(new THREE.Vector3(2,y,z).applyMatrix4(frame.matrixWorld),direction);
    const p=ray.intersectObject(overlay,false)[0],b=ray.intersectObject(under,false)[0];
    if(!p||!b||p.face.normal.x<.999)continue;
    const clearance=b.distance-p.distance;samples++;
    if(clearance<minClearance){minClearance=clearance;worst={y,z};}
    if(clearance<0)pierced++;
  }
  results.push({part:part+'_'+side,samples,minClearance,pierced,worst,passed:samples>0&&minClearance>=.005});
}
const report={file,passed:results.every(r=>r.passed),test:'Flat visible front faces must stand at least 5mm ahead of underlying armor in this 8.12m model; bevel/junction faces excluded.',results};
await writeFile(file+'.panels.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
if(!report.passed)process.exitCode=1;
