// Run inside a configured Kiln workspace. KILN_CLI may select another installed
// Kiln CLI .mjs entrypoint. This script authors no geometry or animation.
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const destination=resolve(root,process.argv[2]??'output/rebuilt-jaeger');
const cli=resolve(process.env.KILN_CLI??resolve(root,'kiln.mjs'));
await readFile(cli);await mkdir(destination,{recursive:true});
function run(args,options={}){
  const r=spawnSync(process.execPath,args,{cwd:root,env:{...process.env,KILN_RENDER:'cpu'},encoding:'utf8',maxBuffer:8*1024*1024,...options});
  if(r.error)throw r.error;if(r.status!==0)throw new Error(r.stderr||r.stdout||'Command failed');
  return r.stdout.trim();
}
const refs={};
for(const batch of ['ground-combat','boost-weapons']){
  console.log(run(['scripts/assemble-jaeger.mjs',`--batch=${batch}`]));
  refs[batch]=run([cli,'source',`jaeger-${batch}.kiln.js`]);
  console.log(`${batch}: ${refs[batch]}`);
  const output=run([cli,'render',refs[batch],'--out',resolve(destination,`${batch}.glb`),'--render','cpu']);
  await writeFile(resolve(destination,`${batch}-export.txt`),output);
}
console.log(run(['scripts/assemble-jaeger.mjs']));
console.log(run(['scripts/package-jaeger.mjs',resolve(destination,'ground-combat.glb'),resolve(destination,'boost-weapons.glb'),resolve(destination,'jaeger-complete.glb')]));
console.log(run(['scripts/verify-jaeger.mjs',resolve(destination,'jaeger-complete.glb')]));
await writeFile(resolve(destination,'program-refs.json'),JSON.stringify(refs,null,2));
