// Package two native Kiln GLBs on their identical rig. Geometry and animation
// accessor bytes remain unchanged; only second-batch accessor indices move.
// Format: https://registry.khronos.org/glTF/specs/2.0/glTF-2.0.html
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {resolve} from 'node:path';

const hash=b=>createHash('sha256').update(b).digest('hex');
function parse(bytes){
  assert.equal(bytes.readUInt32LE(0),0x46546c67,'GLB magic');
  assert.equal(bytes.readUInt32LE(4),2,'GLB version');
  assert.equal(bytes.readUInt32LE(8),bytes.length,'GLB total length');
  let json,bin;
  for(let at=12;at<bytes.length;){
    const n=bytes.readUInt32LE(at),kind=bytes.readUInt32LE(at+4);
    const data=bytes.subarray(at+8,at+8+n);assert.equal(data.length,n);
    if(kind===0x4e4f534a)json=JSON.parse(data.toString('utf8'));
    else if(kind===0x004e4942)bin=data;
    else throw new Error('Unsupported GLB chunk '+kind);
    at+=8+n;
  }
  assert.ok(json&&bin,'JSON and BIN chunks required');
  assert.equal(json.buffers.length,1,'Single embedded buffer required');
  assert.equal(json.buffers[0].uri,undefined,'Embedded buffer required');
  return {json,bin,bytes};
}
function neutralNodes(nodes){
  return nodes.map(n=>{
    const v=structuredClone(n);
    if(v.extras?.animationContract)delete v.extras.animationContract;
    return v;
  });
}
function encode(json,bin){
  const raw=Buffer.from(JSON.stringify(json));
  const js=Buffer.alloc(Math.ceil(raw.length/4)*4,0x20);raw.copy(js);
  const padded=Buffer.alloc(Math.ceil(bin.length/4)*4);bin.copy(padded);
  const header=Buffer.alloc(12);header.writeUInt32LE(0x46546c67);header.writeUInt32LE(2,4);header.writeUInt32LE(28+js.length+padded.length,8);
  const jc=Buffer.alloc(8);jc.writeUInt32LE(js.length);jc.writeUInt32LE(0x4e4f534a,4);
  const bc=Buffer.alloc(8);bc.writeUInt32LE(padded.length);bc.writeUInt32LE(0x004e4942,4);
  return Buffer.concat([header,jc,js,bc,padded]);
}
const [aPath,bPath,outPath]=process.argv.slice(2);
if(!outPath)throw new Error('Usage: node scripts/package-jaeger.mjs first.glb second.glb output.glb');
const a=parse(await readFile(aPath)),b=parse(await readFile(bPath));
const same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
assert.ok(same(neutralNodes(a.json.nodes),neutralNodes(b.json.nodes)),'Rig/node identity');
const sceneGraph=scenes=>scenes.map(s=>{const v=structuredClone(s);if(v.extras)delete v.extras.kilnReviewClipsV1;return v;});
assert.ok(same(sceneGraph(a.json.scenes),sceneGraph(b.json.scenes)),'Scene graph identity');
for(const key of ['scene','meshes','materials','skins','textures','images','samplers','extensionsUsed','extensionsRequired'])assert.ok(same(a.json[key],b.json[key]),key+' identity');
const out=structuredClone(a.json),parts=[a.bin.subarray(0,a.json.buffers[0].byteLength)];
// Kiln retains its exact review tracks in scene extras as well as native glTF
// channels. Keep both batches there so its viewer/inspection metadata agrees.
for(let i=0;i<out.scenes.length;i++){
  const first=out.scenes[i].extras?.kilnReviewClipsV1,second=b.json.scenes[i].extras?.kilnReviewClipsV1;
  if(first||second){assert.equal(first?.version,1);assert.equal(second?.version,1);first.clips.push(...structuredClone(second.clips));}
}
let length=parts[0].length;
const viewMap=new Map(),accessorMap=new Map();
function copyView(index){
  if(viewMap.has(index))return viewMap.get(index);
  const v=structuredClone(b.json.bufferViews[index]);assert.ok(v);assert.equal(v.buffer,0);assert.equal(v.extensions,undefined,'Compressed views unsupported');
  const padding=(4-length%4)%4;if(padding){parts.push(Buffer.alloc(padding));length+=padding;}
  const start=v.byteOffset??0,bytes=b.bin.subarray(start,start+v.byteLength);assert.equal(bytes.length,v.byteLength);
  v.byteOffset=length;length+=bytes.length;parts.push(bytes);
  const next=out.bufferViews.length;out.bufferViews.push(v);viewMap.set(index,next);return next;
}
function copyAccessor(index){
  if(accessorMap.has(index))return accessorMap.get(index);
  const v=structuredClone(b.json.accessors[index]);assert.ok(v);
  if(v.bufferView!==undefined)v.bufferView=copyView(v.bufferView);
  if(v.sparse){v.sparse.indices.bufferView=copyView(v.sparse.indices.bufferView);v.sparse.values.bufferView=copyView(v.sparse.values.bufferView);}
  const next=out.accessors.length;out.accessors.push(v);accessorMap.set(index,next);return next;
}
const names=new Set(out.animations.map(c=>c.name));
for(const clip of b.json.animations){
  assert.ok(!names.has(clip.name),'Duplicate clip '+clip.name);names.add(clip.name);
  const c=structuredClone(clip);
  for(const s of c.samplers){s.input=copyAccessor(s.input);s.output=copyAccessor(s.output);}
  out.animations.push(c);
}
// Portable provenance identifies content and logical batches, not a user's
// local filesystem. Moving the rebuild folder must not change the GLB bytes.
const provenance={authoredWith:'Kiln',packaging:'Native Kiln animation batches combined on an identical node graph; no geometry or keyframe values modified.',inputs:[{batch:'ground-combat',sha256:hash(a.bytes),clips:a.json.animations.map(c=>c.name)},{batch:'boost-weapons',sha256:hash(b.bytes),clips:b.json.animations.map(c=>c.name)}]};
out.asset.extras={...out.asset.extras,kilnBatchPackaging:provenance};
for(const node of out.nodes)if(node.extras?.animationContract){node.extras.animationContract.exportBatch='packaged-all';node.extras.animationContract.packagedTrackCount=out.animations.reduce((n,c)=>n+c.channels.length,0);}
out.buffers[0].byteLength=length;
const bin=Buffer.concat(parts),bytes=encode(out,bin),parsed=parse(bytes);
assert.equal(parsed.json.animations.length,16,'All sixteen clips required');
assert.ok(parsed.bin.subarray(0,a.json.buffers[0].byteLength).equals(parts[0]),'First batch bytes unchanged');
for(const [from,to]of viewMap){
  const x=b.json.bufferViews[from],y=out.bufferViews[to];
  assert.ok(b.bin.subarray(x.byteOffset??0,(x.byteOffset??0)+x.byteLength).equals(parsed.bin.subarray(y.byteOffset,y.byteOffset+y.byteLength)),'Animation bytes unchanged');
}
await writeFile(outPath,bytes,{flag:'wx'});
const receipt={ok:true,file:resolve(outPath),sha256:hash(bytes),bytes:bytes.length,clips:out.animations.map(c=>({name:c.name,tracks:c.channels.length})),preservedGeometry:true,preservedAnimationAccessorBytes:true,provenance};
await writeFile(outPath+'.packaging.json',JSON.stringify(receipt,null,2));
console.log(JSON.stringify(receipt,null,2));
