$ErrorActionPreference = 'Stop'
$jaegerRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$stagePath = Join-Path $jaegerRoot 'output/delivery-v4'
$zipPath = Join-Path $jaegerRoot 'output/jaeger-complete-v4.zip'
if ((Test-Path -LiteralPath $stagePath) -or (Test-Path -LiteralPath $zipPath)) { throw 'Delivery paths already exist; choose a new version.' }
$files = @(
  'README.md', 'motion-design.md', 'jaeger.kiln.js',
  'jaeger-ground-combat.kiln.js', 'jaeger-boost-weapons.kiln.js',
  'reference/approved-mech.png', 'docs/jaeger-demo-spec.md', 'docs/texture-optimization.md', 'docs/implementation-goal.md',
  'parts/core.js', 'parts/materials.js', 'parts/body.js', 'parts/legs.js', 'parts/arms.js', 'parts/markings.js', 'parts/animations.js',
  'scripts/assemble-jaeger.mjs', 'scripts/package-jaeger.mjs', 'scripts/rebuild-jaeger.mjs', 'scripts/verify-jaeger.mjs', 'scripts/load-glb-node.mjs', 'scripts/check-leg-panels.mjs', 'scripts/compare-texture-pass.mjs', 'scripts/bundle-jaeger.ps1',
  'output/jaeger-complete-v4.glb', 'output/jaeger-complete-v4.glb.verification.json', 'output/jaeger-complete-v4.glb.packaging.json', 'output/jaeger-complete-v4.glb.texture-comparison.json',
  'output/jaeger-ground-combat-v4.glb', 'output/jaeger-boost-weapons-v4.glb',
  'output/jaeger-ground-combat-v4-editable.zip', 'output/jaeger-boost-weapons-v4-editable.zip',
  'output/texture-v4-delivery-0.png', 'output/texture-v4-delivery.json'
)
$files += Get-ChildItem -LiteralPath (Join-Path $jaegerRoot 'output') -File | Where-Object { $_.Name -match '^motion-v4-.*\.(png|json)$' } | ForEach-Object { 'output/' + $_.Name }
$manifestEntries = @()
foreach ($relative in $files) {
  $sourcePath = Join-Path $jaegerRoot $relative
  $destinationPath = Join-Path $stagePath $relative
  [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($destinationPath)) | Out-Null
  Copy-Item -LiteralPath $sourcePath -Destination $destinationPath
  $manifestEntries += [ordered]@{ path = $relative; bytes = (Get-Item -LiteralPath $destinationPath).Length; sha256 = (Get-FileHash -LiteralPath $destinationPath -Algorithm SHA256).Hash.ToLowerInvariant() }
}
$manifest = [ordered]@{
  schema = 'kiln-jaeger-portable-package/v1'
  asset = 'output/jaeger-complete-v4.glb'
  authoring = 'Kiln geometry, procedural PBR textures, rig and animation; two native exports combined without changing geometry/keyframe bytes'
  runtime = @{ version = '0.7.1'; commit = '2ddabd656717ac29fffb4d947f6ed4b3001f664f' }
  acceptance = 'Complete character and motion package; technically verified; owner visual approval separate'
  files = $manifestEntries
}
$manifest | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $stagePath 'manifest.json') -Encoding utf8
Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::CreateFromDirectory($stagePath, $zipPath, [IO.Compression.CompressionLevel]::Optimal, $false)
$archive = [IO.Compression.ZipFile]::OpenRead($zipPath)
try {
  foreach ($expected in $manifestEntries) {
    $entry = $archive.GetEntry($expected.path)
    if ($null -eq $entry) { throw ('ZIP is missing ' + $expected.path) }
    $stream = $entry.Open()
    try { $actualHash = ([BitConverter]::ToString(([Security.Cryptography.SHA256]::Create()).ComputeHash($stream))).Replace('-', '').ToLowerInvariant() } finally { $stream.Dispose() }
    if ($actualHash -ne $expected.sha256) { throw ('ZIP hash mismatch for ' + $expected.path) }
  }
} finally { $archive.Dispose() }
[ordered]@{ passed = $true; zip = $zipPath; files = $manifestEntries.Count; bytes = (Get-Item -LiteralPath $zipPath).Length; sha256 = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant() } | ConvertTo-Json
