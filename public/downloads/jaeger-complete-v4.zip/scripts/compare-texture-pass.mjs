// Compare the delivered GLBs, including decoded texture pixels and loaded clips.
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { loadGlbNode } from './load-glb-node.mjs';
const beforePath = process.argv[2] ?? 'output/jaeger-complete-v3.glb';
const afterPath = process.argv[3] ?? 'output/jaeger-complete-v4.glb';
const [aBytes, bBytes] = await Promise.all([readFile(beforePath), readFile(afterPath)]);
const [a, b] = await Promise.all([loadGlbNode(aBytes), loadGlbNode(bBytes)]);
const nodes = scene => {
  const found = new Map();
  scene.traverse(node => { assert(!found.has(node.name), `Duplicate node ${node.name}`); found.set(node.name, node); });
  return found;
};
const before = nodes(a.gltf.scene), after = nodes(b.gltf.scene);
const removed = [...before.keys()].filter(name => !after.has(name)).sort();
const expectedRemoved = ['Mesh_ChestStencil_2_03', 'Mesh_ChestCornerWear',
  ...[...before.keys()].filter(name => /^Mesh_.*(?:Fastener|Bolt).*Socket$/u.test(name))].sort();
assert.equal(expectedRemoved.length, 13);
assert.deepEqual(removed, expectedRemoved);
assert.deepEqual([...after.keys()].filter(name => !before.has(name)), []);
const editedSurfaces = new Set(['Mesh_ChestArmor_L', ...expectedRemoved.filter(name => name.endsWith('Socket')).map(name => name.slice(0, -6))]);
function triangles(mesh, attribute) {
  const g = mesh.geometry, index = g.index, a = g.attributes[attribute], values = [];
  if (!a) return null;
  for (let i = 0; i < (index?.count ?? a.count); i++) {
    const vertex = index ? index.getX(i) : i;
    for (let k = 0; k < a.itemSize; k++) values.push(a[['getX','getY','getZ','getW'][k]](vertex));
  }
  return values;
}
let meshes = 0, triangleCount = 0;
for (const [name, node] of after) {
  const previous = before.get(name);
  assert.deepEqual(node.position.toArray(), previous.position.toArray(), name);
  assert.deepEqual(node.quaternion.toArray(), previous.quaternion.toArray(), name);
  assert.deepEqual(node.scale.toArray(), previous.scale.toArray(), name);
  assert.equal(node.parent?.name, previous.parent?.name, name);
  if (!node.isMesh) continue;
  meshes++;
  triangleCount += (node.geometry.index?.count ?? node.geometry.attributes.position.count) / 3;
  assert.deepEqual(triangles(node, 'position'), triangles(previous, 'position'), `${name} shape`);
  assert.deepEqual(triangles(node, 'normal'), triangles(previous, 'normal'), `${name} normals`);
  if (!editedSurfaces.has(name)) {
    assert.deepEqual(triangles(node, 'uv'), triangles(previous, 'uv'), `${name} UVs`);
    assert.equal(node.material.name, previous.material.name, `${name} material`);
  }
}
assert.equal(b.gltf.animations.length, 16);
let tracks = 0;
for (const clip of b.gltf.animations) {
  const old = a.gltf.animations.find(c => c.name === clip.name);
  assert(old, clip.name); assert.equal(clip.duration, old.duration);
  assert.equal(clip.tracks.length, old.tracks.length);
  for (const track of clip.tracks) {
    const prior = old.tracks.find(t => t.name === track.name);
    assert(prior, track.name); tracks++;
    assert.deepEqual(track.times, prior.times, `${track.name} times`);
    assert.deepEqual(track.values, prior.values, `${track.name} values`);
    assert.equal(track.getInterpolation(), prior.getInterpolation());
  }
}
for (const image of a.images) {
  const retained = b.images.find(i => i.name === image.name);
  assert.equal(retained?.decodedSha256, image.decodedSha256, `Shared texture changed: ${image.name}`);
}
const out = { passed: true, before: beforePath, after: afterPath,
  sha256: createHash('sha256').update(bBytes).digest('hex'), removedNodes: removed,
  retainedMeshes: meshes, triangles: triangleCount, clips: 16, tracks,
  retainedGeometryNormalsTransformsAndAnimationValuesUnchanged: true,
  originalSharedTexturesUnchanged: true, embeddedImages: b.images.length,
  bytesBefore: aBytes.length, bytesAfter: bBytes.length,
  limitations: ['Does not measure frame time or establish final artistic acceptance.'] };
await writeFile(`${afterPath}.texture-comparison.json`, JSON.stringify(out, null, 2));
console.log(JSON.stringify(out, null, 2));
