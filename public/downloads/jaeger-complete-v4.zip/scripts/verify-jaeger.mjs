#!/usr/bin/env node
/** Export-level checks and measured contact evidence for the Kiln Jaeger. */
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { basename, dirname, join, resolve } from 'node:path';
import { loadGlbNode, materialTextureSlots } from './load-glb-node.mjs';
const EPSILON = 1e-5;
const EXPECTED_CLIPS = ['Idle', 'Walk', 'TurnLeft', 'TurnRight', 'SlashLeft', 'SlashRight', 'SlashCombo', 'OverheadStrike', 'CannonAim', 'CannonFire', 'JumpPrepare', 'Takeoff', 'Hover', 'ForwardFlight', 'Landing', 'HitRecovery'];
const EXPECTED_JOINTS = ['Joint_MotionRoot', 'Joint_Pelvis', 'Joint_Torso', 'Joint_Head', ...['R', 'L'].flatMap(side => ['Hip', 'Knee', 'Ankle', 'Toe', 'ShoulderSwing', 'UpperArmTwist', 'Elbow', 'ForearmTwist', 'Wrist', 'ShoulderCap', 'CannonBackpackMount', 'CannonYaw', 'CannonPitch', 'CannonSlide'].map(joint => `Joint_${joint}_${side}`))];
const STATIONARY_CONTACT_CLIPS = ['Idle', 'SlashLeft', 'SlashRight', 'SlashCombo', 'OverheadStrike', 'CannonAim', 'CannonFire', 'JumpPrepare', 'HitRecovery'];
const CONTACT = { groundY: 0, soleToleranceMeters: 0.04, penetrationToleranceMeters: 0.025, ankleSlipToleranceMeters: 0.02, sampleRateHz: 30 };
// Agreed with the motion author; independent expected values, not acceptance inferred from asset output.
const stationary = (duration, startPose = 'Standing', endPose = 'Standing', loop = false) => ({ duration, startPose, endPose, loop, rootDelta: [0, 0, 0], planted: { R: [[0, duration]], L: [[0, duration]] } });
const MOTION_CONTRACT = {
  Idle: stationary(4, 'Standing', 'Standing', true),
  Walk: { duration: 2.8, startPose: 'Standing', endPose: 'StandingTranslated', loop: true, rootDelta: [3.2, 0, 0], planted: { R: [[0, 0.12], [0.62, 1.52], [2.02, 2.8]], L: [[0, 0.72], [1.22, 2.12], [2.62, 2.8]] } },
  TurnLeft: { duration: 4, startPose: 'Standing', endPose: 'StandingRotated', rootDelta: [0, 0, 0], rootYawDeltaDegrees: 90, planted: { R: [[0, 0.15], [0.9, 2.1], [2.85, 4]], L: [[0, 1.1], [1.85, 3.1], [3.85, 4]] } },
  TurnRight: { duration: 4, startPose: 'Standing', endPose: 'StandingRotated', rootDelta: [0, 0, 0], rootYawDeltaDegrees: -90, planted: { R: [[0, 0.15], [0.9, 2.1], [2.85, 4]], L: [[0, 1.1], [1.85, 3.1], [3.85, 4]] } },
  SlashLeft: stationary(2.5), SlashRight: stationary(2.5), SlashCombo: stationary(3.7), OverheadStrike: stationary(3.2),
  CannonAim: stationary(1.2, 'Standing', 'CannonReady'), CannonFire: stationary(1.8, 'CannonReady', 'CannonReady', true),
  JumpPrepare: stationary(1.1, 'Standing', 'LaunchCrouch'),
  Takeoff: { duration: 1.35, startPose: 'LaunchCrouch', endPose: 'Hover', rootDelta: [0, 2, 0], planted: { R: [[0, 0.24]], L: [[0, 0.24]] } },
  Hover: { duration: 3.2, startPose: 'Hover', endPose: 'Hover', loop: true, rootStart: [0, 2, 0], rootDelta: [0, 0, 0], planted: { R: [], L: [] } },
  ForwardFlight: { duration: 3.4, startPose: 'Hover', endPose: 'HoverTranslated', rootStart: [0, 2, 0], rootDelta: [4, 0, 0], planted: { R: [], L: [] } },
  Landing: { duration: 2, startPose: 'Hover', endPose: 'Standing', rootStart: [0, 2, 0], rootDelta: [0, -2, 0], planted: { R: [[0.68, 2]], L: [[0.68, 2]] } },
  HitRecovery: stationary(2.2),
};
const receipt = {
  schema: 'kiln-jaeger-glb-verification/v1', passed: false, checks: [],
  acceptance: 'export-and-sampled-motion-evidence-only',
  limitations: [
    'A structural pass does not establish final artistic acceptance or reference-image fidelity.',
    'Contact evidence samples actual exported geometry and transforms; it is not continuous collision or dynamics proof.',
    'Material properties are inspected as data; this script does not render or judge PBR appearance.',
    'Open surfaces are inventoried; outward signed-volume assertions apply only to consistently oriented closed surfaces.',
    'Rigid node animation does not require a glTF skin or deforming skeleton.',
  ],
  poseContract: {
    axes: { forward: '+X', up: '+Y', right: '+Z' },
    stationaryClips: STATIONARY_CONTACT_CLIPS,
    stationaryAnklePositions: { R: [0, 0.68, 0.69], L: [0, 0.68, -0.69] },
    rootMotion: { Walk: { axis: 'X', displacementMeters: 3.2, durationSeconds: 2.8 }, TurnLeft: { yawDegrees: 90, durationSeconds: 4 }, TurnRight: { yawDegrees: -90, durationSeconds: 4 } },
    contactTolerances: CONTACT,
    clips: MOTION_CONTRACT,
    airborneTransitions: 'Takeoff ends in Hover at rootY2; ForwardFlight advances rootX4; Landing starts at rootY2. Carry horizontal origin between clips.',
  },
};
function check(name, passed, details = {}) { receipt.checks.push({ name, passed: Boolean(passed), ...details }); }

function requireValue(condition, message) {
  if (!condition) throw new Error(message);
}

function finiteTree(value, label) {
  if (typeof value === 'number') requireValue(Number.isFinite(value), `${label} contains a nonfinite number`);
  else if (Array.isArray(value)) value.forEach((v, i) => finiteTree(v, `${label}[${i}]`));
  else if (value && typeof value === 'object') {
    for (const [key, entry] of Object.entries(value)) finiteTree(entry, `${label}.${key}`);
  }
}

function parseGlb(bytes) {
  requireValue(bytes.length >= 20, 'File is too short to be a GLB');
  requireValue(bytes.readUInt32LE(0) === 0x46546c67, 'Invalid GLB magic');
  requireValue(bytes.readUInt32LE(4) === 2, 'Expected GLB version 2');
  requireValue(bytes.readUInt32LE(8) === bytes.length, 'GLB byte length does not match its header');
  let json;
  let binary;
  const chunks = [];
  for (let offset = 12; offset < bytes.length;) {
    requireValue(offset + 8 <= bytes.length, 'Truncated GLB chunk header');
    const length = bytes.readUInt32LE(offset);
    const type = bytes.readUInt32LE(offset + 4);
    requireValue(length % 4 === 0, 'GLB chunk length is not four-byte aligned');
    requireValue(offset + 8 + length <= bytes.length, 'Truncated GLB chunk data');
    const data = bytes.subarray(offset + 8, offset + 8 + length);
    if (!chunks.length) requireValue(type === 0x4e4f534a, 'First GLB chunk must be JSON');
    if (type === 0x4e4f534a) {
      requireValue(json === undefined, 'Multiple JSON chunks');
      json = JSON.parse(data.toString('utf8').replace(/[\u0000 ]+$/u, ''));
    } else if (type === 0x004e4942) {
      requireValue(binary === undefined, 'Multiple BIN chunks');
      binary = data;
    }
    chunks.push({ type: `0x${type.toString(16)}`, byteLength: length });
    offset += 8 + length;
  }
  requireValue(json?.asset?.version === '2.0', 'Expected glTF asset version 2.0');
  finiteTree(json, 'glTF JSON');
  requireValue((json.buffers ?? []).length <= 1, 'Verifier requires a self-contained GLB with at most one buffer');
  const buffer = json.buffers?.[0];
  if (buffer) {
    requireValue(!buffer.uri, 'External or data-URI buffers are not supported in this GLB proof');
    requireValue(binary && binary.length >= buffer.byteLength, 'BIN chunk is shorter than the declared buffer');
    requireValue(binary.length - buffer.byteLength <= 3, 'Unexpected extra BIN bytes');
  }
  check('glb-container', true, { chunks, generator: json.asset.generator ?? null });
  return { json, binary: binary ?? Buffer.alloc(0) };
}

function accessorReader(json, binary) {
  const dataView = new DataView(binary.buffer, binary.byteOffset, binary.byteLength);
  const components = {
    5120: [1, 'getInt8'], 5121: [1, 'getUint8'],
    5122: [2, 'getInt16'], 5123: [2, 'getUint16'],
    5125: [4, 'getUint32'], 5126: [4, 'getFloat32'],
  };
  const shapes = { SCALAR: [1, 1], VEC2: [1, 2], VEC3: [1, 3], VEC4: [1, 4], MAT2: [2, 2], MAT3: [3, 3], MAT4: [4, 4] };
  const cache = new Map();
  function viewAt(index) {
    const view = json.bufferViews?.[index];
    requireValue(view && (view.buffer ?? 0) === 0, `Invalid bufferView ${index}`);
    const offset = view.byteOffset ?? 0;
    requireValue(Number.isInteger(offset) && offset >= 0 && Number.isInteger(view.byteLength) && view.byteLength >= 0, `Invalid bufferView range ${index}`);
    requireValue(offset + view.byteLength <= (json.buffers?.[0]?.byteLength ?? 0), `bufferView ${index} exceeds buffer`);
    return { ...view, byteOffset: offset };
  }
  function componentAt(offset, componentType, normalized) {
    const [, method] = components[componentType];
    let value = dataView[method](offset, true);
    if (normalized) {
      if (componentType === 5120) value = Math.max(value / 127, -1);
      if (componentType === 5121) value /= 255;
      if (componentType === 5122) value = Math.max(value / 32767, -1);
      if (componentType === 5123) value /= 65535;
      if (componentType === 5125) value /= 4294967295;
    }
    requireValue(Number.isFinite(value), `Nonfinite accessor component at byte ${offset}`);
    return value;
  }
  return function readAccessor(index) {
    if (cache.has(index)) return cache.get(index);
    const accessor = json.accessors?.[index];
    requireValue(accessor && components[accessor.componentType] && shapes[accessor.type], `Invalid accessor ${index}`);
    requireValue(Number.isInteger(accessor.count) && accessor.count >= 0, `Invalid accessor count ${index}`);
    const [size] = components[accessor.componentType];
    const [columns, rows] = shapes[accessor.type];
    const width = columns * rows;
    const columnStride = columns > 1 ? Math.ceil(rows * size / 4) * 4 : rows * size;
    const elementSize = columnStride * columns;
    const values = new Float64Array(accessor.count * width);
    const readElement = (offset, destination) => {
      for (let column = 0; column < columns; column++) {
        for (let row = 0; row < rows; row++) {
          values[destination + column * rows + row] = componentAt(offset + column * columnStride + row * size, accessor.componentType, accessor.normalized);
        }
      }
    };
    if (accessor.bufferView !== undefined) {
      const view = viewAt(accessor.bufferView);
      const localOffset = accessor.byteOffset ?? 0;
      const stride = view.byteStride ?? elementSize;
      requireValue(Number.isInteger(localOffset) && localOffset >= 0 && localOffset % size === 0, `Invalid accessor offset ${index}`);
      requireValue(Number.isInteger(stride) && stride >= elementSize && stride % size === 0, `Invalid accessor stride ${index}`);
      const end = accessor.count ? localOffset + (accessor.count - 1) * stride + elementSize : localOffset;
      requireValue(end <= view.byteLength, `Accessor ${index} exceeds its bufferView`);
      for (let i = 0; i < accessor.count; i++) readElement(view.byteOffset + localOffset + i * stride, i * width);
    } else requireValue((accessor.byteOffset ?? 0) === 0, `Accessor ${index} has offset without a bufferView`);
    if (accessor.sparse) {
      const sparse = accessor.sparse;
      requireValue(Number.isInteger(sparse.count) && sparse.count >= 0 && sparse.count <= accessor.count, `Invalid sparse count ${index}`);
      requireValue([5121, 5123, 5125].includes(sparse.indices.componentType), `Invalid sparse index type ${index}`);
      const indices = viewAt(sparse.indices.bufferView);
      const sparseValues = viewAt(sparse.values.bufferView);
      const [indexSize] = components[sparse.indices.componentType];
      const indexOffset = sparse.indices.byteOffset ?? 0;
      const valueOffset = sparse.values.byteOffset ?? 0;
      requireValue(indexOffset >= 0 && indexOffset + sparse.count * indexSize <= indices.byteLength, `Sparse indices exceed view ${index}`);
      requireValue(valueOffset >= 0 && valueOffset + sparse.count * elementSize <= sparseValues.byteLength, `Sparse values exceed view ${index}`);
      let previous = -1;
      for (let i = 0; i < sparse.count; i++) {
        const destination = componentAt(indices.byteOffset + indexOffset + i * indexSize, sparse.indices.componentType, false);
        requireValue(destination > previous && destination < accessor.count, `Invalid or unsorted sparse index ${index}`);
        readElement(sparseValues.byteOffset + valueOffset + i * elementSize, destination * width);
        previous = destination;
      }
    }
    const result = { ...accessor, width, values };
    cache.set(index, result);
    return result;
  };
}

function endpointError(first, last, rotation) {
  const direct = Math.max(...first.map((value, i) => Math.abs(value - last[i])));
  if (!rotation) return direct;
  const antipodal = Math.max(...first.map((value, i) => Math.abs(value + last[i])));
  return Math.min(direct, antipodal);
}

function inspectExport(json, binary) {
  const nodes = json.nodes ?? [];
  const parents = new Array(nodes.length).fill(null);
  const byName = new Map();
  nodes.forEach((node, index) => {
    if (node.name) byName.set(node.name, [...(byName.get(node.name) ?? []), index]);
    for (const child of node.children ?? []) {
      requireValue(Number.isInteger(child) && nodes[child], `Invalid child of node ${index}`);
      requireValue(parents[child] === null, `Node ${child} has multiple parents`);
      parents[child] = index;
    }
    for (const [field, width] of [['translation', 3], ['rotation', 4], ['scale', 3], ['matrix', 16]]) {
      if (node[field]) requireValue(Array.isArray(node[field]) && node[field].length === width, `Invalid ${field} on node ${index}`);
    }
    requireValue(!(node.matrix && (node.translation || node.rotation || node.scale)), `Node ${index} mixes matrix and TRS`);
    if (node.mesh !== undefined) requireValue(json.meshes?.[node.mesh], `Invalid mesh on node ${index}`);
  });
  const visited = new Set();
  function visit(index, active = new Set()) {
    requireValue(!active.has(index), `Cycle in hierarchy at node ${index}`);
    if (visited.has(index)) return;
    active.add(index);
    for (const child of nodes[index].children ?? []) visit(child, active);
    active.delete(index);
    visited.add(index);
  }
  nodes.forEach((_, index) => visit(index));
  const reachable = new Set();
  function markReachable(index) {
    requireValue(Number.isInteger(index) && nodes[index], `Invalid scene root ${index}`);
    reachable.add(index);
    for (const child of nodes[index].children ?? []) markReachable(child);
  }
  const scene = json.scenes?.[json.scene ?? 0];
  requireValue(scene, 'No default scene');
  for (const index of scene.nodes ?? []) markReachable(index);
  check('valid-node-hierarchy', true, { nodes: nodes.length, reachableNodes: reachable.size });
  receipt.nodes = nodes.map((node, index) => ({ index, parent: parents[index], reachable: reachable.has(index), ...node }));
  receipt.exportedAnimationContracts = nodes.filter(node => node.extras?.animationContract).map(node => ({ node: node.name ?? null, contract: node.extras.animationContract }));
  receipt.skins = { count: json.skins?.length ?? 0, requiredForRigidAnimation: false };
  for (const name of EXPECTED_JOINTS) {
    const matches = byName.get(name) ?? [];
    check(`required-joint:${name}`, matches.length === 1 && reachable.has(matches[0]), { matches });
  }
  const fixtureNodes = nodes.filter(node => /fixture|display.?stand|test.?stand|mounting.?block/i.test(node.name ?? '')).map(node => node.name);
  check('no-fixture-named-nodes', fixtureNodes.length === 0, { fixtureNodes });
  function descendsFrom(index, ancestor) {
    for (let parent = parents[index]; parent !== null; parent = parents[parent]) if (parent === ancestor) return true;
    return false;
  }
  for (const side of ['R', 'L']) {
    const shoulder = byName.get(`Joint_ShoulderSwing_${side}`)?.[0];
    const cannons = nodes.map((node, index) => /cannon/i.test(node.name ?? '') && node.name?.endsWith(`_${side}`) ? index : null).filter(index => index !== null);
    const misplaced = cannons.filter(index => descendsFrom(index, shoulder)).map(index => nodes[index].name);
    check(`independent-cannon:${side}`, shoulder !== undefined && cannons.length > 0 && misplaced.length === 0, { cannonNodes: cannons.map(index => nodes[index].name), misplaced });
  }

  const readAccessor = accessorReader(json, binary);
  receipt.accessors = (json.accessors ?? []).map((accessor, index) => {
    const decoded = readAccessor(index);
    return { index, type: accessor.type, componentType: accessor.componentType, count: accessor.count, normalized: accessor.normalized ?? false, componentCount: decoded.values.length, finite: true };
  });
  check('all-accessors-finite', true, { accessors: receipt.accessors.length, components: receipt.accessors.reduce((sum, accessor) => sum + accessor.componentCount, 0) });
  receipt.materials = (json.materials ?? []).map((material, index) => ({ index, ...material }));
  const invalidMaterialRanges = [];
  receipt.materials.forEach(material => {
    const pbr = material.pbrMetallicRoughness ?? {};
    if ([pbr.metallicFactor ?? 1, pbr.roughnessFactor ?? 1, ...(pbr.baseColorFactor ?? [1, 1, 1, 1])].some(value => value < 0 || value > 1)) invalidMaterialRanges.push(material.index);
  });
  check('material-factors-and-presence', receipt.materials.length > 0 && invalidMaterialRanges.length === 0, { count: receipt.materials.length, invalidMaterialRanges });
  receipt.materialTextureSlots = (json.materials ?? []).map((material, materialIndex) => ({ materialIndex, name: material.name ?? null, slots: materialTextureSlots(material) }));
  for (const material of receipt.materialTextureSlots) {
    for (const slot of material.slots) {
      requireValue(Number.isInteger(slot.index) && json.textures?.[slot.index], `Material ${material.materialIndex}:${slot.path} has an unresolved texture`);
      requireValue(Number.isInteger(slot.texCoord) && slot.texCoord >= 0, `Material ${material.materialIndex}:${slot.path} has invalid texCoord`);
    }
  }
  receipt.textureUvEvidence = [];
  let primitives = 0;
  for (const [meshIndex, mesh] of (json.meshes ?? []).entries()) {
    for (const [primitiveIndex, primitive] of (mesh.primitives ?? []).entries()) {
      primitives++;
      const positions = readAccessor(primitive.attributes?.POSITION);
      requireValue(positions.type === 'VEC3', `Mesh ${meshIndex} has invalid POSITION accessor`);
      for (const index of Object.values(primitive.attributes ?? {})) requireValue(readAccessor(index).count === positions.count, `Mesh ${meshIndex} attribute count mismatch`);
      if (primitive.indices !== undefined) {
        const indices = readAccessor(primitive.indices);
        requireValue(indices.type === 'SCALAR' && [5121, 5123, 5125].includes(indices.componentType), `Mesh ${meshIndex} index type invalid`);
        for (const index of indices.values) requireValue(Number.isInteger(index) && index >= 0 && index < positions.count, `Mesh ${meshIndex} index outside vertex buffer`);
      }
      requireValue(primitive.material === undefined || json.materials?.[primitive.material], `Mesh ${meshIndex} material does not resolve`);
      const slots = receipt.materialTextureSlots[primitive.material]?.slots ?? [];
      for (const channel of new Set(slots.map(slot => slot.texCoord))) {
        const uvIndex = primitive.attributes[`TEXCOORD_${channel}`];
        requireValue(uvIndex !== undefined, `Textured mesh ${meshIndex}:${primitiveIndex} has no TEXCOORD_${channel}`);
        const uv = readAccessor(uvIndex);
        requireValue(uv.type === 'VEC2' && uv.count === positions.count, `Invalid UV dimensions on textured mesh ${meshIndex}:${primitiveIndex}`);
        let minU = Infinity, maxU = -Infinity, minV = Infinity, maxV = -Infinity;
        for (let index = 0; index < uv.count; index++) {
          const u = uv.values[index * 2], v = uv.values[index * 2 + 1];
          minU = Math.min(minU, u); maxU = Math.max(maxU, u); minV = Math.min(minV, v); maxV = Math.max(maxV, v);
        }
        requireValue(maxU > minU && maxV > minV, `Completely collapsed UV range on textured mesh ${meshIndex}:${primitiveIndex}`);
        receipt.textureUvEvidence.push({ meshIndex, meshName: mesh.name ?? null, primitiveIndex, materialIndex: primitive.material, texCoord: channel, accessor: uvIndex, count: uv.count, finite: true, minU, maxU, minV, maxV, slots: slots.filter(slot => slot.texCoord === channel).map(slot => slot.path) });
      }
    }
  }
  check('mesh-accessor-and-material-references', primitives > 0, { meshes: json.meshes?.length ?? 0, primitives });
  check('textured-primitives-have-finite-usable-uvs', true, { checkedUvSets: receipt.textureUvEvidence.length, materialSlots: receipt.materialTextureSlots.reduce((sum, material) => sum + material.slots.length, 0) });

  receipt.animations = [];
  for (const animation of json.animations ?? []) {
    const report = { name: animation.name ?? null, durationSeconds: 0, channels: [] };
    const targets = new Set();
    for (const channel of animation.channels ?? []) {
      const target = channel.target;
      requireValue(target && Number.isInteger(target.node) && reachable.has(target.node), `Unresolved target in ${animation.name}`);
      requireValue(['translation', 'rotation', 'scale', 'weights'].includes(target.path), `Invalid channel path in ${animation.name}`);
      requireValue(!nodes[target.node].matrix, `Animated node ${target.node} uses a matrix`);
      const key = `${target.node}:${target.path}`;
      requireValue(!targets.has(key), `Duplicate animation target ${key}`);
      targets.add(key);
      const sampler = animation.samplers?.[channel.sampler];
      requireValue(sampler, `Unresolved sampler in ${animation.name}`);
      const input = readAccessor(sampler.input), output = readAccessor(sampler.output);
      const interpolation = sampler.interpolation ?? 'LINEAR';
      requireValue(['LINEAR', 'STEP', 'CUBICSPLINE'].includes(interpolation), `Invalid interpolation in ${animation.name}`);
      requireValue(input.type === 'SCALAR' && input.componentType === 5126 && input.count >= 2, `Insufficient float time keys in ${animation.name}`);
      for (let index = 0; index < input.count; index++) requireValue(input.values[index] >= 0 && (index === 0 || input.values[index] > input.values[index - 1]), `Non-increasing key time in ${animation.name}`);
      const cubic = interpolation === 'CUBICSPLINE' ? 3 : 1;
      const width = output.values.length / input.count / cubic;
      requireValue(Number.isInteger(width) && width > 0 && (target.path === 'weights' || width === (target.path === 'rotation' ? 4 : 3)), `Invalid output dimensions in ${animation.name}`);
      const at = index => Array.from(output.values.slice((index * cubic + (cubic === 3 ? 1 : 0)) * width, (index * cubic + (cubic === 3 ? 1 : 0) + 1) * width));
      const first = at(0), last = at(input.count - 1);
      let maxKeyDeviationFromFirst = 0;
      for (let index = 0; index < input.count; index++) maxKeyDeviationFromFirst = Math.max(maxKeyDeviationFromFirst, endpointError(first, at(index), target.path === 'rotation'));
      const entry = { target: nodes[target.node].name ?? `node:${target.node}`, node: target.node, path: target.path, interpolation, keys: input.count, first, last, endpointError: endpointError(first, last, target.path === 'rotation'), maxKeyDeviationFromFirst };
      if (target.path === 'translation') {
        entry.range = Array.from({ length: width }, (_, axis) => {
          let min = Infinity, max = -Infinity;
          for (let index = 0; index < input.count; index++) { const value = at(index)[axis]; min = Math.min(min, value); max = Math.max(max, value); }
          return { min, max };
        });
      }
      if (target.path === 'rotation') {
        let maxError = 0;
        for (let index = 0; index < input.count; index++) maxError = Math.max(maxError, Math.abs(Math.hypot(...at(index)) - 1));
        requireValue(maxError <= 1e-4, `Unnormalized quaternion keys in ${animation.name}:${entry.target}`);
        entry.maxQuaternionNormError = maxError;
      }
      report.channels.push(entry);
      report.durationSeconds = Math.max(report.durationSeconds, input.values[input.count - 1]);
    }
    receipt.animations.push(report);
  }
  const actualClips = receipt.animations.map(animation => animation.name);
  check('exact-sixteen-animation-clips', actualClips.length === EXPECTED_CLIPS.length && EXPECTED_CLIPS.every(name => actualClips.filter(actual => actual === name).length === 1), { expected: EXPECTED_CLIPS, actual: actualClips });
  check('animation-targets-and-accessors', receipt.animations.every(animation => animation.channels.length > 0), { clips: receipt.animations.length });
  const meleeTargets = receipt.animations.filter(animation => /Slash|Overhead/.test(animation.name)).flatMap(animation => animation.channels.filter(channel => /Joint_Cannon/.test(channel.target) && channel.maxKeyDeviationFromFirst > EPSILON).map(channel => `${animation.name}:${channel.target}`));
  check('melee-does-not-move-cannon-joints', meleeTargets.length === 0, { changingTargets: meleeTargets, constantBakedTracksAllowed: true });
  for (const side of ['R', 'L']) {
    const channel = receipt.animations.find(animation => animation.name === 'CannonFire')?.channels.find(entry => entry.target === `Joint_CannonSlide_${side}` && entry.path === 'translation');
    check(`cannon-local-x-recoil:${side}`, Boolean(channel) && channel.range[0].max - channel.range[0].min > EPSILON, { range: channel?.range ?? null });
  }
}

function inspectGeometry(mesh, THREE) {
  const geometry = mesh.geometry, position = geometry.attributes.position, indices = geometry.index;
  const count = indices?.count ?? position.count;
  requireValue(count % 3 === 0, `Mesh ${mesh.name} is not triangular`);
  geometry.computeBoundingBox();
  const center = geometry.boundingBox.getCenter(new THREE.Vector3());
  const a = new THREE.Vector3(), b = new THREE.Vector3(), c = new THREE.Vector3();
  const ab = new THREE.Vector3(), ac = new THREE.Vector3(), cross = new THREE.Vector3();
  const edges = new Map();
  let signedVolume = 0, area = 0, degenerateTriangles = 0;
  const key = vertex => [vertex.x, vertex.y, vertex.z].map(value => Math.round(value * 1e7)).join(',');
  for (let index = 0; index < count; index += 3) {
    a.fromBufferAttribute(position, indices ? indices.getX(index) : index).sub(center);
    b.fromBufferAttribute(position, indices ? indices.getX(index + 1) : index + 1).sub(center);
    c.fromBufferAttribute(position, indices ? indices.getX(index + 2) : index + 2).sub(center);
    signedVolume += a.dot(cross.crossVectors(b, c)) / 6;
    const triangleArea = cross.crossVectors(ab.subVectors(b, a), ac.subVectors(c, a)).length() / 2;
    area += triangleArea;
    if (triangleArea < 1e-12) degenerateTriangles++;
    for (const [start, end] of [[a, b], [b, c], [c, a]]) {
      const from = key(start), to = key(end), edgeKey = from < to ? `${from}|${to}` : `${to}|${from}`;
      const edge = edges.get(edgeKey) ?? { count: 0, balance: 0 };
      edge.count++;
      edge.balance += from < to ? 1 : -1;
      edges.set(edgeKey, edge);
    }
  }
  const values = [...edges.values()];
  const boundaryEdges = values.filter(edge => edge.count === 1).length;
  const nonManifoldEdges = values.filter(edge => edge.count > 2).length;
  const windingConflicts = values.filter(edge => edge.count === 2 && edge.balance !== 0).length;
  const closed = boundaryEdges === 0 && nonManifoldEdges === 0 && windingConflicts === 0 && degenerateTriangles === 0;
  return { name: mesh.name, triangles: count / 3, area, localSignedVolume: signedVolume, worldSignedVolume: signedVolume * mesh.matrixWorld.determinant(), boundaryEdges, nonManifoldEdges, windingConflicts, degenerateTriangles, consistentlyClosed: closed, outward: closed ? signedVolume > 1e-12 : null };
}

function footSample(foot, THREE) {
  let minY = Infinity, maxY = -Infinity, minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity, vertices = 0;
  const point = new THREE.Vector3();
  foot.traverse(object => {
    if (!object.isMesh) return;
    const positions = object.geometry.attributes.position;
    for (let index = 0; index < positions.count; index++) {
      point.fromBufferAttribute(positions, index).applyMatrix4(object.matrixWorld);
      minY = Math.min(minY, point.y); maxY = Math.max(maxY, point.y);
      minX = Math.min(minX, point.x); maxX = Math.max(maxX, point.x);
      minZ = Math.min(minZ, point.z); maxZ = Math.max(maxZ, point.z);
      vertices++;
    }
  });
  requireValue(vertices > 0, `No exported foot geometry under ${foot.name}`);
  const ankle = foot.getWorldPosition(point).toArray();
  const quaternion = foot.getWorldQuaternion(new THREE.Quaternion()).toArray();
  return { ankle, quaternion, minY, maxY, aabbXZ: [minX, maxX, minZ, maxZ], vertices, grounded: Math.abs(minY - CONTACT.groundY) <= CONTACT.soleToleranceMeters };
}

function capturePose(joints) {
  return Object.fromEntries(joints.map(joint => [joint.name, { position: joint.position.toArray(), quaternion: joint.quaternion.toArray(), scale: joint.scale.toArray() }]));
}

function comparePoses(first, second, excludeRoot = false) {
  let maxPositionDelta = 0, maxRotationDegrees = 0, maxScaleDelta = 0;
  const differences = [];
  for (const [name, from] of Object.entries(first)) {
    if (excludeRoot && name === 'Joint_MotionRoot') continue;
    const to = second[name];
    if (!to) continue;
    const positionDelta = Math.hypot(...from.position.map((value, index) => value - to.position[index]));
    const normProduct = Math.hypot(...from.quaternion) * Math.hypot(...to.quaternion);
    const dot = Math.min(1, Math.abs(from.quaternion.reduce((sum, value, index) => sum + value * to.quaternion[index], 0) / normProduct));
    const rotationDegrees = 2 * Math.acos(dot) * 180 / Math.PI;
    const scaleDelta = Math.max(...from.scale.map((value, index) => Math.abs(value - to.scale[index])));
    maxPositionDelta = Math.max(maxPositionDelta, positionDelta);
    maxRotationDegrees = Math.max(maxRotationDegrees, rotationDegrees);
    maxScaleDelta = Math.max(maxScaleDelta, scaleDelta);
    if (positionDelta > 1e-4 || rotationDegrees > 0.01 || scaleDelta > 1e-5) differences.push({ joint: name, positionDelta, rotationDegrees, scaleDelta });
  }
  return { maxPositionDelta, maxRotationDegrees, maxScaleDelta, differences };
}

async function inspectRuntime(bytes, json) {
  const loaded = await loadGlbNode(bytes);
  const { gltf, THREE } = loaded;
  receipt.dependencies = loaded.dependencies;
  receipt.images = loaded.images;
  receipt.textures = loaded.textures;
  receipt.textureUsage = loaded.textureUsage;
  check('actual-embedded-pngs-decoded', loaded.images.length === (json.images?.length ?? 0) && loaded.images.every(image => image.finite && image.width > 0 && image.height > 0), { images: loaded.images.length, decodedBytes: loaded.images.reduce((sum, image) => sum + image.decodedBytes, 0) });
  const coreSlots = { 'pbrMetallicRoughness.baseColorTexture': ['map'], 'pbrMetallicRoughness.metallicRoughnessTexture': ['metalnessMap', 'roughnessMap'], normalTexture: ['normalMap'], occlusionTexture: ['aoMap'], emissiveTexture: ['emissiveMap'] };
  const inspectedMaterials = new Set();
  const materialMapEvidence = [];
  gltf.scene.traverse(object => {
    if (!object.isMesh) return;
    for (const material of Array.isArray(object.material) ? object.material : [object.material]) {
      if (inspectedMaterials.has(material.uuid)) continue;
      inspectedMaterials.add(material.uuid);
      const materialIndex = gltf.parser.associations.get(material)?.materials;
      const expected = receipt.materialTextureSlots[materialIndex];
      if (!expected) continue;
      for (const slot of expected.slots) {
        requireValue(coreSlots[slot.path], `Unverified material texture extension slot ${slot.path}`);
        for (const property of coreSlots[slot.path]) {
          const texture = material[property];
          requireValue(texture?.isDataTexture && texture.userData.gltfTextureIndex === slot.index && texture.channel === slot.texCoord, `Loaded material ${material.name}:${property} does not match exported slot ${slot.path}`);
          const expectedColorSpace = ['map', 'emissiveMap'].includes(property) ? THREE.SRGBColorSpace : THREE.NoColorSpace;
          requireValue(texture.colorSpace === expectedColorSpace, `Loaded material ${material.name}:${property} has wrong color space`);
          const decodedHash = loaded.images[texture.userData.gltfImageIndex]?.decodedSha256;
          requireValue(decodedHash && createHash('sha256').update(texture.image.data).digest('hex') === decodedHash, `Loaded material ${material.name}:${property} differs from decoded PNG bytes`);
          materialMapEvidence.push({ materialIndex, material: material.name, exportedSlot: slot.path, loadedProperty: property, textureIndex: slot.index, texCoord: slot.texCoord, colorSpace: texture.colorSpace, decodedSha256: decodedHash });
        }
      }
    }
  });
  receipt.materialMapEvidence = materialMapEvidence;
  const expectedTexturedMaterials = receipt.materialTextureSlots.filter(material => material.slots.length > 0);
  check('exported-material-slots-use-actual-png-pixels', expectedTexturedMaterials.every(material => materialMapEvidence.some(entry => entry.materialIndex === material.materialIndex)), { checkedBindings: materialMapEvidence.length, texturedMaterials: expectedTexturedMaterials.length });
  gltf.scene.updateMatrixWorld(true);
  const meshes = [], joints = [], badDeterminants = [];
  gltf.scene.traverse(object => {
    if (object.isMesh) meshes.push(object);
    if (object.name.startsWith('Joint_')) joints.push(object);
    const determinant = object.matrixWorld.determinant();
    if (!(Number.isFinite(determinant) && determinant > 0)) badDeterminants.push({ name: object.name, determinant });
  });
  check('positive-rest-world-determinants', badDeterminants.length === 0, { badDeterminants });
  receipt.geometry = meshes.map(mesh => inspectGeometry(mesh, THREE));
  const inward = receipt.geometry.filter(mesh => mesh.consistentlyClosed && !mesh.outward).map(mesh => ({ name: mesh.name, signedVolume: mesh.localSignedVolume }));
  const closedCount = receipt.geometry.filter(mesh => mesh.consistentlyClosed).length;
  check('closed-geometry-outward-winding', closedCount > 0 && inward.length === 0, { meshes: meshes.length, closed: closedCount, openOrIrregular: meshes.length - closedCount, inward });
  const irregular = receipt.geometry.filter(mesh => mesh.nonManifoldEdges || mesh.windingConflicts || mesh.degenerateTriangles).map(mesh => ({ name: mesh.name, nonManifoldEdges: mesh.nonManifoldEdges, windingConflicts: mesh.windingConflicts, degenerateTriangles: mesh.degenerateTriangles }));
  check('no-irregular-geometry-topology', irregular.length === 0, { irregular });
  const root = gltf.scene.getObjectByName('Joint_MotionRoot');
  const feet = { R: gltf.scene.getObjectByName('Joint_Ankle_R'), L: gltf.scene.getObjectByName('Joint_Ankle_L') };
  requireValue(root && feet.R && feet.L, 'Named motion root and both ankle subtrees are required for contact evidence');
  const rest = joints.map(joint => ({ joint, position: joint.position.clone(), quaternion: joint.quaternion.clone(), scale: joint.scale.clone() }));
  const restore = () => rest.forEach(({ joint, position, quaternion, scale }) => { joint.position.copy(position); joint.quaternion.copy(quaternion); joint.scale.copy(scale); });
  receipt.runtime = { threeRevision: THREE.REVISION, sampleRateHz: CONTACT.sampleRateHz, clips: [], transitions: [], contactEvidence: 'Actual transformed vertices below each named ankle node; ankle drift reports world-space movement.' };
  const endpoints = new Map();
  for (const clip of gltf.animations) {
    restore();
    const mixer = new THREE.AnimationMixer(gltf.scene);
    const action = mixer.clipAction(clip);
    action.setLoop(THREE.LoopOnce, 1); action.clampWhenFinished = true; action.play();
    const contract = MOTION_CONTRACT[clip.name];
    const frames = Math.max(2, Math.ceil(clip.duration * CONTACT.sampleRateHz));
    const sampleTimes = [...new Set([
      ...Array.from({ length: frames + 1 }, (_, frame) => clip.duration * frame / frames),
      ...Object.values(contract?.planted ?? {}).flat(2).map(time => Math.min(time, clip.duration)),
    ])].filter(time => time >= 0 && time <= clip.duration).sort((a, b) => a - b);
    const samples = [];
    let minimumDeterminant = Infinity, transformSamples = 0;
    let firstPose, lastPose;
    const worldPosition = new THREE.Vector3();
    for (let frame = 0; frame < sampleTimes.length; frame++) {
      const time = sampleTimes[frame];
      action.paused = false;
      mixer.setTime(time);
      gltf.scene.updateMatrixWorld(true);
      gltf.scene.traverse(object => {
        requireValue(object.matrixWorld.elements.every(Number.isFinite), `Nonfinite sampled world transform in ${clip.name}:${object.name}`);
        minimumDeterminant = Math.min(minimumDeterminant, object.matrixWorld.determinant());
        transformSamples++;
      });
      if (frame === 0) firstPose = capturePose(joints);
      if (frame === sampleTimes.length - 1) lastPose = capturePose(joints);
      samples.push({ time, rootPosition: root.getWorldPosition(worldPosition).toArray(), rootQuaternion: root.quaternion.toArray(), feet: { R: footSample(feet.R, THREE), L: footSample(feet.L, THREE) } });
    }
    const contact = {};
    for (const side of ['R', 'L']) {
      const footSamples = samples.map(sample => sample.feet[side]);
      const firstAnkle = footSamples[0].ankle;
      const maxAnkleSlip = Math.max(...footSamples.map(sample => Math.hypot(sample.ankle[0] - firstAnkle[0], sample.ankle[2] - firstAnkle[2])));
      const minSoleY = Math.min(...footSamples.map(sample => sample.minY)), maxSoleY = Math.max(...footSamples.map(sample => sample.minY));
      contact[side] = { minSoleY, maxSoleY, maxAnkleSlip, groundedFrames: footSamples.filter(sample => sample.grounded).length, totalFrames: footSamples.length };
      check(`no-sampled-foot-penetration:${clip.name}:${side}`, minSoleY >= CONTACT.groundY - CONTACT.penetrationToleranceMeters, { minSoleY, toleranceMeters: CONTACT.penetrationToleranceMeters });
      if (STATIONARY_CONTACT_CLIPS.includes(clip.name)) {
        check(`stationary-foot-contact:${clip.name}:${side}`, footSamples.every(sample => sample.grounded) && maxAnkleSlip <= CONTACT.ankleSlipToleranceMeters, { ...contact[side], tolerances: CONTACT });
      }
      contact[side].plantedIntervals = [];
      for (const [start, end] of contract?.planted?.[side] ?? []) {
        const intervalSamples = samples.filter(sample => sample.time >= start - 1e-6 && sample.time <= end + 1e-6).map(sample => sample.feet[side]);
        requireValue(intervalSamples.length > 0, `No planted samples for ${clip.name}:${side}:${start}-${end}`);
        const initial = intervalSamples[0];
        const ankleSlip = Math.max(...intervalSamples.map(sample => Math.hypot(sample.ankle[0] - initial.ankle[0], sample.ankle[2] - initial.ankle[2])));
        const ankleHeightDeviation = Math.max(...intervalSamples.map(sample => Math.abs(sample.ankle[1] - 0.68)));
        const minHeight = Math.min(...intervalSamples.map(sample => sample.minY)), maxHeight = Math.max(...intervalSamples.map(sample => sample.minY));
        const interval = { start, end, sampledFrames: intervalSamples.length, maxAnkleSlip: ankleSlip, maxAnkleHeightDeviation: ankleHeightDeviation, minSoleY: minHeight, maxSoleY: maxHeight, firstAnkle: initial.ankle, lastAnkle: intervalSamples.at(-1).ankle };
        contact[side].plantedIntervals.push(interval);
        check(`planted-phase:${clip.name}:${side}:${start}-${end}`, intervalSamples.every(sample => sample.grounded) && ankleSlip <= CONTACT.ankleSlipToleranceMeters && ankleHeightDeviation <= CONTACT.soleToleranceMeters, interval);
      }
    }
    const first = samples[0], last = samples.at(-1);
    const rootDisplacement = last.rootPosition.map((value, index) => value - first.rootPosition[index]);
    const rootStartQ = new THREE.Quaternion().fromArray(first.rootQuaternion).normalize();
    const rootEndQ = new THREE.Quaternion().fromArray(last.rootQuaternion).normalize();
    const rootYawDeltaDegrees = new THREE.Euler().setFromQuaternion(rootStartQ.invert().multiply(rootEndQ), 'YXZ').y * 180 / Math.PI;
    const clipReport = { name: clip.name, durationSeconds: clip.duration, sampledFrames: samples.length, transformSamples, minimumDeterminant, rootDisplacement, rootYawDeltaDegrees, contact, endpointComparison: comparePoses(firstPose, lastPose), endpointComparisonExcludingRoot: comparePoses(firstPose, lastPose, true), samples };
    receipt.runtime.clips.push(clipReport);
    endpoints.set(clip.name, { first: firstPose, last: lastPose });
    check(`finite-positive-sampled-transforms:${clip.name}`, minimumDeterminant > 0, { minimumDeterminant, sampledFrames: samples.length, transformSamples });
    if (contract) {
      check(`clip-duration:${clip.name}`, Math.abs(clip.duration - contract.duration) < 1e-4, { actual: clip.duration, expected: contract.duration });
      check(`root-motion-contract:${clip.name}`, endpointError(rootDisplacement, contract.rootDelta, false) < 1e-3 && endpointError(first.rootPosition, contract.rootStart ?? [0, 0, 0], false) < 1e-3 && Math.abs(rootYawDeltaDegrees - (contract.rootYawDeltaDegrees ?? 0)) < 0.02, { firstRootPosition: first.rootPosition, rootDisplacement, rootYawDeltaDegrees, expectedStart: contract.rootStart ?? [0, 0, 0], expectedDisplacement: contract.rootDelta, expectedYawDeltaDegrees: contract.rootYawDeltaDegrees ?? 0 });
      if (contract.loop) check(`loop-pose-excluding-root-motion:${clip.name}`, clipReport.endpointComparisonExcludingRoot.maxPositionDelta < 1e-4 && clipReport.endpointComparisonExcludingRoot.maxRotationDegrees < 0.02, { comparison: clipReport.endpointComparisonExcludingRoot, rootMotionPreserved: rootDisplacement });
    }
    mixer.stopAllAction(); mixer.uncacheRoot(gltf.scene);
  }
  for (const [name, poses] of endpoints) {
    for (const reference of ['Idle', 'Hover']) {
      const target = endpoints.get(reference)?.first;
      if (!target) continue;
      receipt.runtime.transitions.push({ clip: name, referencePose: `${reference}:start`, start: comparePoses(poses.first, target, true), end: comparePoses(poses.last, target, true), excludesMotionRoot: true });
    }
  }
  const poseReferences = {
    Standing: endpoints.get('Idle')?.first,
    StandingTranslated: endpoints.get('Idle')?.first,
    StandingRotated: endpoints.get('Idle')?.first,
    CannonReady: endpoints.get('CannonAim')?.last,
    LaunchCrouch: endpoints.get('JumpPrepare')?.last,
    Hover: endpoints.get('Hover')?.first,
    HoverTranslated: endpoints.get('Hover')?.first,
  };
  receipt.runtime.poseContractComparisons = [];
  for (const [name, poses] of endpoints) {
    const contract = MOTION_CONTRACT[name];
    if (!contract) continue;
    for (const [endpoint, state] of [['first', contract.startPose], ['last', contract.endPose]]) {
      const reference = poseReferences[state];
      requireValue(reference, `No canonical reference pose for ${state}`);
      const comparison = comparePoses(poses[endpoint], reference, true);
      receipt.runtime.poseContractComparisons.push({ clip: name, endpoint, expectedState: state, excludesMotionRoot: true, comparison });
      check(`endpoint-state:${name}:${endpoint}:${state}`, comparison.maxPositionDelta < 1e-4 && comparison.maxRotationDegrees < 0.02 && comparison.maxScaleDelta < 1e-5, { comparison, rootMotionCheckedSeparately: true });
    }
  }
  check('three-loaded-and-sampled-all-clips', EXPECTED_CLIPS.every(name => endpoints.has(name)), { sampledClips: [...endpoints.keys()] });
}

const argument = process.argv[2];
if (!argument || process.argv.length !== 3) {
  console.error('Usage: node scripts/verify-jaeger.mjs path/to/jaeger.glb');
  process.exitCode = 2;
} else {
  const artifact = resolve(argument);
  const receiptPath = join(dirname(artifact), `${basename(artifact)}.verification.json`);
  receipt.artifact = artifact;
  try {
    const bytes = await readFile(artifact);
    receipt.sha256 = createHash('sha256').update(bytes).digest('hex');
    receipt.byteLength = bytes.length;
    const { json, binary } = parseGlb(bytes);
    inspectExport(json, binary);
    await inspectRuntime(bytes, json);
  } catch (error) {
    check('verification-completed', false, { error: error instanceof Error ? error.message : String(error) });
  }
  receipt.passed = receipt.checks.length > 0 && receipt.checks.every(entry => entry.passed);
  try { await writeFile(receiptPath, `${JSON.stringify(receipt, null, 2)}\n`, 'utf8'); }
  catch (error) { console.error(`Could not write receipt: ${error.message}`); process.exitCode = 1; }
  console.log(JSON.stringify({ passed: receipt.passed, acceptance: receipt.acceptance, artifact, receipt: receiptPath, sha256: receipt.sha256 ?? null, checks: receipt.checks.length, failedChecks: receipt.checks.filter(entry => !entry.passed) }, null, 2));
  if (!receipt.passed) process.exitCode = 1;
}


