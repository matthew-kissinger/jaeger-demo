# Jaeger texture optimization

## Implemented in v4

All texture creation, raster painting, UV authoring, geometry and animation remain in the Kiln source. `proceduralTexture` creates owned textures; deterministic code paints their public pixel buffers. The GLB contains the resulting PNGs. No Blender, external image download, or custom runtime shader is required.

| Detail | Change | Removed triangles | Removed mesh objects |
| --- | --- | ---: | ---: |
| 2-03 identification | Paint on the existing chest cap, with its original placement and cant | 1,380 | 1 |
| Four tiny chest paint chips | Paint on the same chest map | 80 | 1 |
| Eleven bolt sockets | Shared color, normal and metallic/roughness maps; bolt heads retain thickness | 1,760 | 11 |
| Total | | 3,220 | 13 |

The chest map is 512 x 512. The three shared fastener maps are 64 x 64. The four original 256 x 256 PBR maps remain byte-identical. Added PNG payload is 18,642 bytes; all eight PNGs total 104,223 bytes and decode to 2,146,304 RGBA bytes before mipmaps. Materials remain opaque, with fourteen unique materials.

The complete GLB changes from 74,840 to 71,620 triangles, 483 to 470 mesh objects, and 3,790,356 to 3,771,340 bytes. The texture pass is a modest geometry/submission improvement, not the major download-size reduction expected from the separate runtime export profile. No FPS improvement is claimed without scene measurement.

## Further candidates

Counts below are inventories of existing geometry, not promised savings. Removing a surface detail requires the surrounding shell to remain closed and its shading to survive close and angled views.

| Detail | Current cost | Recommendation |
| --- | --- | --- |
| Ten shallow backpack vent bars | 440 triangles / 10 objects | Good next color + normal-map candidate on the existing backpack panels. Keep the panel outline. |
| Twelve dorsal-fin vent details | 528 triangles / 12 objects | Candidate after checking both sides and silhouette; the fins are thin enough that profile changes matter. |
| Four thruster heat-color bands | 640 triangles / 4 objects | Color belongs in a texture, but these bands currently supply actual sections of the shield. Replace them with a continuous sleeve before painting; simply deleting them leaves gaps. |
| Fourteen red chest vent slats | 616 triangles / 14 objects | Keep for now. They sit in deep visible recesses and benefit from real parallax and shadows. A distant LOD can bake them. |
| Armor panel borders and insets | Mixed; 37 related objects / 4,348 triangles | Evaluate individually. Painted seams can become texture; raised plate edges that define the form should stay geometry. This inventory is not all removable. |
| Joint rings, hands, blade edges and cannon recesses | Structural and silhouette detail | Keep geometry. Reduce unnecessary radial segments or merge parts that move together instead. |

Use shared atlases where possible. Adding a unique texture and material for every detail can erase the benefit by splitting batches. Painted labels, chips, discoloration, scratches and small surface sockets are the safest texture targets. Texture compression changes storage/transmission and GPU texture format; it does not itself merge geometry or remove draw submissions.

## Proof and limits

- `output/jaeger-complete-v4.glb.verification.json`: 226 export/material/motion checks, sixteen clips sampled across 1,335 frames.
- `output/jaeger-complete-v4.glb.texture-comparison.json`: thirteen expected mesh removals; retained triangle positions/normals, transforms, parent relationships, original shared texture pixels, and all 359 animation tracks unchanged from v3. UVs and materials change only on the chest identification surface and eleven fastener heads.
- `output/texture-v4-delivery-0.png`: material-faithful front/angled/context views, isolated back of chest with no repeated marking, and fastener recess close-up.
- `output/rebuilt-v4-portable-proof/`: full rebuild from source reproduces the delivery GLB hash exactly after removing local paths from packaging provenance.

V4 still has 470 ordinary mesh submissions before scene batching. Its 199 shared mesh definitions and fourteen materials offer more optimization work: direct-parent/material grouping estimates 214 groups, nearest-animated-ancestor/material 137, or 139 when attribute layouts are also separated. These are estimates, not implemented merges; runtime-controlled pivots also need explicit boundaries. Keep the canonical editable version and validate any runtime derivative against it.
