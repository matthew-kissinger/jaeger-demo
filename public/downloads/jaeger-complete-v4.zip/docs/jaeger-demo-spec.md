# Jaeger Demo: Coastal Proving Ground

## 1. Purpose and status

**Version:** 1.1, 2026-09-15. **Status:** implementation plan updated for v4, local playtesting, a separate `jaeger-demo` repository, and GitHub Pages release. Scene implementation has not started.

Build one polished browser scene that demonstrates a complete Kiln-authored mechanical character in motion, with a Kiln-built environment, collisions, controlled destruction, visual effects, and generated sound. Visitors can watch a short showcase, take control, inspect every animation, and download the character.

**Working repository name:** `jaeger-demo`.

**Display title:** Jaeger Demo.

**Subtitle:** Coastal Proving Ground.

**Description:** An interactive mech showcase built with Kiln assets.

The first release succeeds when the Jaeger feels heavy and powerful, its construction and articulation remain visible, the three breakable-prop interactions are satisfying, and the same experience is usable on PC and mobile. This is a contained demo scene with repeatable actions. There is no progression or win condition.

### Reading this specification

- **MUST** means required for the first release.
- **SHOULD** means a proposed implementation or quality target that can change when measurements or visual review justify it. Record the change.
- **LATER** means outside the first release.
- Numerical performance budgets below are proposed targets, not measurements or guarantees.
- Existing asset checks establish the input asset's condition. They do not establish that the future scene, controls, rendering, or physics work.

## 2. Scope and authorship

### First-release requirements

| ID | Requirement |
| --- | --- |
| SCOPE-01 | One coastal industrial proving ground with a single continuous play area. |
| SCOPE-02 | The complete textured v4 Jaeger, all 16 native animation clips, and its rig/socket hierarchy. |
| SCOPE-03 | Watch Demo, Take Control, and an expandable animation inspector. |
| SCOPE-04 | Ground and obstacle collision; physics for loose props and fractured pieces. |
| SCOPE-05 | Three repeatable interactions: scatter crates, slash a target, and blast a concrete barrier apart. |
| SCOPE-06 | Socket-aligned weapon/flight effects, landing dust, generated sound, and carefully framed cameras. |
| SCOPE-07 | PC and touch controls, quality settings, pause, mute, reset, and downloads. |
| SCOPE-08 | A static browser application that runs without Kiln or an audio-generation service at runtime. |
| SCOPE-09 | Performance is part of first-release acceptance: optimize the runtime assets, validate cold actions and frame pacing, and publish only claims supported by recorded device/backend tests. |

### What is generated where

| Content | Authoring requirement |
| --- | --- |
| Jaeger, armor, rig, animation keyframes, sockets | Kiln; preserve the existing editable sources and native exports. |
| Dock, hangar, gantry, truck, crates, targets, barriers, rocks, terrain | Kiln-authored geometry exported to GLB. |
| Concrete and target fracture pieces, exposed interiors | Kiln-authored geometry with matching intact/broken variants. |
| Solid-asset base materials and texture maps | Kiln materials and deterministic procedural maps by default. |
| Water surface, sky, fog, lighting, particle carriers, trails, screen effects | Three.js/TSL runtime rendering. Simple effect geometry is an explicit exception to the Kiln solid-asset rule. |
| Collision proxies, hit volumes, camera paths, placement/configuration | Runtime/configuration data; these are not presented as authored visible assets. |
| Sound effects and ambience | ElevenLabs-generated files, auditioned and edited before inclusion. |
| Interface | HTML/CSS/TypeScript. |

**AUTHOR-01:** Every shipped solid asset MUST have Kiln source provenance. Reuse and instance a small coherent asset kit. Do not substitute downloaded scenery or hand-modeled Blender geometry.

**AUTHOR-02:** Runtime material enhancements MUST preserve the downloadable Jaeger's portable PBR appearance. Keep the canonical download separate from scene-only effects and optional runtime optimizations.

**AUTHOR-03:** The public explanation MUST distinguish Kiln asset authoring, Three.js rendering/control, Rapier physics, and ElevenLabs sound. Do not claim Kiln performs the runtime simulation or that the scene's TSL effects are embedded in the character GLB.

### Later additions

A creature or second hero rig; enemy AI; missions, health, scoring, inventory, or multiplayer; arbitrary voxel destruction; runtime boolean fracture; structural collapse of buildings; destructible terrain; unrestricted flight; ragdolls; terrain walking/climbing; a weather/day-night simulation; music generation; a browser asset editor.

These items do not block the first release. A Kiln-authored armored crustacean is a plausible later character, with its own explicit modeling and animation pass.

## 3. Verified starting asset

Source workspace: [kiln-mech](C:/Users/Mattm/X/kiln-mech).

| Item | Current value |
| --- | --- |
| Canonical GLB | [jaeger-complete-v4.glb](C:/Users/Mattm/X/kiln-mech/output/jaeger-complete-v4.glb) |
| SHA-256 | `14155efa3ebef47839b70632c0b185557d743abcb99d00e2fa093ba75e3553e0` |
| Portable source package | [jaeger-complete-v4.zip](C:/Users/Mattm/X/kiln-mech/output/jaeger-complete-v4.zip) |
| Size | 3,771,340 bytes |
| Geometry | 71,620 triangles; 470 meshes; 564 nodes; 93 named joints |
| Materials | 14 materials; eight embedded PNG maps: four 256 x 256, one 512 x 512, three 64 x 64 |
| Motion | 16 clips; 359 tracks |
| Scale and axes | Approximately 8.12 m tall; metres; +X forward, +Y up, +Z right |
| Native ground/combat source | `p_83b045764971` |
| Native boost/weapons source | `p_c50bf8dd6b42` |
| Motion contract | [motion-design.md](C:/Users/Mattm/X/kiln-mech/motion-design.md) |
| Asset verification | [v4 verification](C:/Users/Mattm/X/kiln-mech/output/jaeger-complete-v4.glb.verification.json), 226 checks passed |

**ASSET-01:** Use v4. The old viewer revision `a_87fe5d7d4f59475fabc8a6fe102fb941 / r_b3c6aa9f69a343ff92ebe02582be0a63` is v2 and MUST NOT become the scene input accidentally.

**ASSET-02:** Preserve the slate-gray armor, yellow visor, cyan accents, white `2-03`, corrected thumbs, and repaired rear/thigh/shin/upper-arm surfaces. Review these areas again in the actual demo renderer.

**ASSET-03:** Copy required source and build records into the future repository. The deliverable MUST not depend on an absolute path to this workstation. Existing absolute links here identify the inputs for the initial handoff.

The installed authoring runtime was verified as Kiln 0.7.1 at `2ddabd656717ac29fffb4d947f6ed4b3001f664f`. Recheck the installed runtime before generating the new environment; record the version actually used. Preserve the current Jaeger's existing provenance if the environment uses a newer engine.

### Is the asset ready?

**Ready for integration; runtime performance remains to be established.** V4 replaces the identification, tiny paint chips, and eleven bolt sockets with Kiln-authored textures, removing 3,220 triangles and thirteen mesh objects. Remaining geometry and normals, all retained node transforms/parents, all 359 animation tracks, and the original four texture maps match v3. The entire v4 rebuild is now byte-reproducible across output folders. See [texture optimization](texture-optimization.md).

The remaining 470 mesh submissions are the first optimization priority. Do not delay all scene work waiting for an abstract "optimal asset," and do not build the full presentation on an unmeasured hero. Gate 0 below qualifies a runtime derivative in a minimal renderer first. The canonical v4 GLB and editable sources remain the fidelity reference.

## 4. Scene composition and terrain

### Art direction

A working industrial dock set into a rocky coast. Warm, low-angle sunlight catches the armor; cooler sky illumination separates its shaded surfaces. Concrete is darker and less reflective than the Jaeger. Orange hazard details and cyan weapon effects provide restrained accent colors.

**ART-01:** Establish scale through a normal service truck, approximately human-sized doors, stairs, railings, and equipment. Keep the Jaeger at its current physical scale. Giant-kaiju city scale is not implied.

**ART-02:** Provide three strong views: the arrival/hero view, a full-body action view, and a wider flight/landing view. Keep the silhouette readable against both the hangar and the coast.

**ART-03:** Environment detail MUST support the character. Avoid dense background machinery, excessive decals, heavy fog over the subject, or effects that hide the animation.

### Spatial plan

Initial layout target: a roughly **48 m x 36 m** concrete deck, with an inset operating area and a clear action corridor at least 8 m wide. These are blockout dimensions; tune them against the actual animated bounds before final asset authoring.

- Rear edge: hangar facade and maintenance gantry, outside the attack/flight corridor.
- Arrival area: Jaeger, parked truck, and small equipment cluster.
- Central corridor: crate stack, melee target, and a clear route between demonstrations.
- Downrange: concrete break target and two target pylons, with an empty backdrop behind shots.
- Separate marked clear area: takeoff, low flight, and landing.
- Seaward edge: raised curb/seawall, visible boundary lights, then rocks and water below deck level.
- Landward edge: a low rocky bluff enclosing the composition.

The cinematic route SHOULD reach attacks through short walks and deliberate turns; position targets to suit the current motion range. Do not build a huge empty arena to compensate for unplanned choreography.

### Terrain requirements

| ID | Requirement |
| --- | --- |
| TERRAIN-01 | The combat/walking deck is genuinely level at the chosen world ground height. Surface texture detail must not displace the walking surface. |
| TERRAIN-02 | The surroundings use actual uneven Kiln-authored terrain geometry: rocky slopes, shoreline shelves, and a low bluff. They are not just a flat plane with a noisy color map. |
| TERRAIN-03 | Terrain generation uses a saved seed, low-frequency height variation, controlled ridges/erosion-like shaping, and restrained finer detail. Mask the deck footprint and stitch or conceal terrain edges. |
| TERRAIN-04 | Terrain noise is generated during Kiln authoring and exported. The scene does not regenerate solid terrain outside Kiln at load time. |
| TERRAIN-05 | Uneven terrain is scenic and outside the first-release movement envelope. Boundaries are visibly communicated; neither walking nor flight can cross onto it. |
| TERRAIN-06 | Terrain silhouette, slopes, normals, and visible seams are reviewed from the full camera orbit and flight view. Noise alone is not an acceptable finished landscape. |
| TERRAIN-07 | Water stays below the deck and meets the coast coherently. A shoreline foam band may hide the visual seam; no buoyancy or swimming system is required. |

## 5. Kiln asset inventory

Counts are initial scene instances, not commitments to unique models. Every family needs a material-faithful review before final placement.

| Family | Initial quantity | Visible requirements | Collision/destruction |
| --- | ---: | --- | --- |
| Jaeger v4 | 1 | Existing approved construction and finish | Kinematic controller; separate weapon queries |
| Concrete deck module | Repeated kit | Beveled edges, expansion joints, subtle roughness | Combined simple static deck collider |
| Seawall/curb module | Repeated kit | Coherent thickness and boundary markings | Static, unbreakable |
| Hangar facade | 1 | Large mech entrance plus human-scale service door | Static facade; no playable interior |
| Gantry kit | 1 assembly | Supports, catwalk, stairs, railings | Static bounding proxies; outside play lane |
| Maintenance truck | 1 | Believable scale and readable silhouette | Parked static obstacle; not driveable |
| Equipment crate | 6-8 | One family with two finish variants | Dynamic box bodies; pushed/scattered |
| Armored melee target | 1 | Contact region matched to blade reach; structural interior | Intact plus 6-10 large pieces |
| Concrete break barrier | 2 | Thick construction, visible concrete interior on fragments | Intact plus 8-12 pieces per barrier |
| Cannon target pylon | 2 | Target faces placed at actual firing height | Static hit feedback; optional toppling head if budget permits |
| Shore terrain sections | 1 coherent set | Uneven coast, low bluff, deck integration | Static coarse proxy or excluded scenic area |
| Rock cluster variants | 3-5 reused | Deliberate silhouettes, shared materials | Static scenery |
| Boundary fixtures | Reused | Bollards, warning markers, modest lamps | Merge/instance; simple boundary collider |

**ENV-01:** All intact and fractured variants use the same local origin, units, and placement convention. Fragments have solid interiors and stored transforms.

**ENV-02:** Environment materials SHOULD reuse a small shared palette: concrete, painted steel, exposed steel, rubber, rock, and emissive markers. Use Kiln procedural texture maps; external texture packs are unnecessary for the baseline.

**ENV-03:** Collision proxies, placement, source references, material categories, and fracture metadata MUST be machine-readable rather than inferred from arbitrary mesh names at runtime.

## 6. Visitor experience and interface

### Startup

**UX-01:** Show the title, a lightweight hero poster, concise loading progress, and three clear choices: **Watch Demo**, **Take Control**, **Download GLB**. Loading must not leave a blank canvas.

**UX-02:** A Start/Watch/Control gesture unlocks audio. Provide a persistent mute control and respect a saved mute preference. A soundless visitor can use every visual/interactive feature.

**UX-03:** Essential shaders, GLB data, physics, and action sounds MUST be ready before enabling their actions. If loading fails, present Retry and keep a working download link where possible.

### Watch Demo

**DEMO-01:** A 35-45 second sequence demonstrates weight, articulation, weapons, controlled destruction, and low flight. It uses the same action/event system as pilot mode.

| Approximate time | Beat | Purpose |
| --- | --- | --- |
| 0-4 s | Low view past truck/railings; idle Jaeger | Scale and material introduction |
| 4-10 s | Walk through crates; turn toward range | Ground contact and dynamic props |
| 10-15 s | Aim, fire both cannons; barrier breaks | Independent recoil and destruction |
| 15-23 s | Short reposition; combo breaks melee target on second hit; overhead breaks second concrete target | Full-body melee and blade trails |
| 23-35 s | Prepare, take off, hover, short forward flight, land | Exhaust, root motion, dust, weight |
| 35-40 s | Three-quarter hero view; effects settle | Clear ending and call to interact |

The timeline is a shot plan. Final timestamps MUST be derived from actual clip durations, accepted retiming, and route lengths; do not speed up individual events merely to hit a timestamp.

**DEMO-02:** Include Replay and Take Control. Taking control completes the current critical recovery/landing or briefly fades to the known start state; it must not hand control over midway through an unsupported pose.

**DEMO-03:** Replaying resets the physical scene before beginning. There must be no hard visible teleport halfway through a shot. Small camera cuts may cover intentional repositioning between sequences if documented.

### Take Control and inspection

**UX-04:** Keep primary controls to movement/turn, Slash, Cannon, Boost/Land, camera, and Reset. Put individual clips and secondary options in a drawer.

**UX-05:** The animation inspector lists all 16 exact clip names and provides Play/Pause, scrub, replay, playback speed, and reset view. It uses a reserved clear inspection position, not the last arbitrary location among props.

**UX-06:** Scrubbing has no damage, physics impulses, or repeated audio events. Entering inspection pauses the physical scene; leaving it restores a supported standing start state. Offer an optional joints/sockets overlay for viewing the rig; joint editing is outside scope.

**UX-07:** Include a small About/Credits panel explaining asset generation and runtime technologies, plus GLB and source-package downloads. Backend diagnostics and detailed statistics belong in a collapsed debug panel.

## 7. Controls and movement contract

The current asset supports forward walking and quarter turns. It has no reverse, strafe, run, or high-altitude flight clips. The first release uses an **animation-led movement pad**, not a twin-stick shooter controller.

| Intent | PC default | Mobile |
| --- | --- | --- |
| Forward | W / Up; hold to continue | Hold Forward |
| Turn left/right | A/D or Left/Right | Left/Right pads |
| Stop/clear movement intention | Release Forward; S/Down requests stop | Release Forward / Stop control |
| Slash | J; alternate left/right | Slash button |
| Combo / overhead | Animation/action drawer | Same drawer |
| Cannon burst | K | Cannon button |
| Boost / land | Space, context-sensitive | Boost/Land button |
| Camera | Drag to orbit; wheel zoom | Swipe outside controls; pinch zoom |
| Pause/help | Escape / visible menu | Visible menu |
| Reset | Visible button; R when canvas has focus | Visible button |

**INPUT-01:** A/D turn; S stops. Do not label these as strafing/backward motion. Camera orbit does not change weapon direction.

**INPUT-02:** The baseline preserves complete 90-degree turn paths. Test a turn playback speed of up to 2x as a candidate to reduce a four-second turn to two seconds; choose it only after reviewing weight, contacts, and effect timing. An accepted turn completes after release; release prevents another turn from starting. Holding can repeat at completed endpoints. Ignore keyboard auto-repeat events as separate requests. The inspector defaults to native 1x playback.

**INPUT-03:** Forward motion MUST start and stop through validated supported poses. Prefer contact-aware stopping at a both-feet-supported phase. Double support can leave staggered feet; a transition must preserve their world contacts and settle into a valid standing stance. An unexplained full-cycle delay or freezing mid-step is not acceptable. Target forward-walk release-to-stable-stop within 0.8 seconds in free space, measured across releases throughout the cycle; this target does not apply to completing an accepted quarter turn or flight segment. If existing clips cannot meet it cleanly, author a small transition in Kiln and identify it as an additional helper clip. Preserve the original 16 clips.

**INPUT-04:** Input feedback appears within 100 ms on tested devices, even when an action is recovering. Maintain only the latest movement intention and at most one queued action. Reset/Pause takes precedence. Clear held input on blur, pointer cancellation, orientation change, or hidden tab.

**INPUT-05:** Walking and quarter turns are serialized initially. Continuous analog steering, arbitrary partial turns, and strafing require additional motion work and are not silently assumed.

**INPUT-06:** Mobile supports separate simultaneous pointers for movement, camera, and actions. Use at least 48 CSS-pixel targets, safe-area spacing, and portrait/landscape layouts. No essential hover interactions or pointer-lock requirement. Apply touch restrictions to the interactive canvas/control area without disabling ordinary document accessibility globally.

**INPUT-07:** Movement and attack commands never accumulate indefinitely. Repeated presses during critical landing or recovery produce clear busy/queued feedback, not state corruption.

## 8. Animation integration

### Required native clips

| Clip | Native duration | End state / event |
| --- | ---: | --- |
| Idle | 4.00 s | Standing loop |
| Walk | 2.80 s | Standing, translated +3.2 m forward |
| TurnLeft | 4.00 s | Standing, rotated +90 degrees Y |
| TurnRight | 4.00 s | Standing, rotated -90 degrees Y |
| SlashLeft | 2.50 s | Standing; strike at 1.00 s |
| SlashRight | 2.50 s | Standing; strike at 1.00 s |
| SlashCombo | 3.70 s | Standing; strikes at 1.00 and 2.20 s |
| OverheadStrike | 3.20 s | Standing; strike at 1.52 s |
| CannonAim | 1.20 s | CannonReady |
| CannonFire | 1.80 s | CannonReady; shots at 0.40 and 0.67 s |
| JumpPrepare | 1.10 s | LaunchCrouch |
| Takeoff | 1.35 s | Hover; leaves support after 0.24 s |
| Hover | 3.20 s | Hover loop; approximately 2 m root lift |
| ForwardFlight | 3.40 s | Hover, translated +4.0 m forward |
| Landing | 2.00 s | Standing; ground contact at 0.68 s |
| HitRecovery | 2.20 s | Standing; exposed through Test Impact/inspector |

### Root motion and transitions

**ANIM-01:** `Joint_MotionRoot` has one owner. Extract desired root translation/rotation from animation, resolve motion against world constraints, and commit the accepted world transform exactly once. Remove or compensate the extracted local root motion so it is not applied a second time by the visual hierarchy.

**ANIM-02:** Align incoming clip starts to the current world transform. Accumulate horizontal motion and heading across cycles. Treat hover height as an absolute pose offset relative to support, not an increment per loop. Landing consumes the takeoff offset once.

**ANIM-03:** Physics rejection and visual animation MUST agree. If a wall blocks a step, transition to a stable pose instead of translating armor through the wall or continuing an endless walk-in-place. Test translation and rotational clearance before starting tightly constrained actions.

**ANIM-04:** Default compatible cross-fades are approximately 0.12-0.25 s. Different foot-support states require contact-aware correction or Kiln-authored transitions. A generic blend alone is not proof of planted feet.

**ANIM-05:** Cinematic and pilot modes use the same state machine. Supported paths are:

```mermaid
stateDiagram-v2
    [*] --> Standing
    Standing --> Walk
    Walk --> Standing
    Standing --> Turn
    Turn --> Standing
    Standing --> Melee
    Melee --> Standing
    Standing --> CannonAim
    CannonAim --> CannonReady
    CannonReady --> CannonFire
    CannonFire --> CannonReady
    CannonReady --> Standing: lower weapons
    Standing --> JumpPrepare
    JumpPrepare --> Takeoff
    Takeoff --> Hover
    Hover --> ForwardFlight
    ForwardFlight --> Hover
    Hover --> Landing: support area clear
    Landing --> LandingAbort: obstruction before contact
    LandingAbort --> Hover: return along checked descent path
    ForwardFlight --> FlightBrake: new obstruction
    FlightBrake --> Hover: safe stationary pose
    Landing --> Standing
    Standing --> HitRecovery
    HitRecovery --> Standing
```

**ANIM-06:** At 30/60/variable frame rates, events use crossings of animation time, not frame numbers or wall-clock timeouts. Deduplicate by action instance, loop, event, and target. Retiming must carry the event schedule with it. Suppress outgoing-action effects during irrelevant blend tails.

**ANIM-07:** Ground attacks cannot start during flight. Landing compression cannot be interrupted by an attack. A Cannon request first enters CannonReady. A second Cannon request can repeat firing; lowering weapons uses a tested exit transition.

**ANIM-08:** The inspector can play unsupported combinations in isolation, but Pilot mode cannot. HitRecovery is a controlled Test Impact action, not a requirement to add an enemy.

## 9. Collision, physics, and safe flight

**Selected physics approach:** Rapier 3D, fixed-step simulation, kinematic Jaeger and dynamic loose objects. Exact package version is resolved and pinned at implementation start. Rapier's controller corrects requested translations against obstacles; it does not provide rotational collision handling. A kinematic body alone does not stop at walls. [Rapier character controller](https://rapier.rs/docs/user_guides/javascript/character_controller/), [rigid bodies](https://rapier.rs/docs/user_guides/javascript/rigid_bodies/)

| ID | Requirement |
| --- | --- |
| PHYS-01 | Use a 1/60 s physics step, interpolated presentation, and a bounded accumulator of at most four substeps. After a larger stall, discard excess simulation time consistently: animation, root motion, physics, action events, effects, and timeline consume the same accepted delta. Still report the raw stalled frame interval in performance captures. Pause/resume discards stale elapsed time. |
| PHYS-02 | Use a simple measured capsule/cuboid envelope for the Jaeger, static proxies for architecture, and boxes/convex hulls for props and chunks. Do not simulate all 470 hero meshes as rigid bodies. |
| PHYS-03 | Add explicit turn/swept-armor clearance checks or conservative clearance zones. The translation controller does not cover rotating arms, blades, or cannons. |
| PHYS-04 | Dynamic crates receive bounded contact impulses from accepted Jaeger motion. Tune the controller's effective mass/impulses for heavy readable interaction, without explosive launches. |
| PHYS-05 | Define groups for static world, Jaeger, pushable props, large debris, cosmetic fragments, and weapon sensors. Small debris cannot trap feet or prevent landing. |
| PHYS-06 | Full body collision remains active in pilot flight. Decorative terrain and water are outside the permitted flight envelope. |
| PHYS-07 | Fast weapon hits use ray/shape sweeps. Do not depend on a small discrete projectile body landing inside a collider on one frame. |

### Flight envelope

**FLIGHT-01:** Flight is the current low boost sequence, approximately 2 m root lift and 4 m travel per ForwardFlight clip. It is not free six-axis flight or an arbitrary jump-height controller.

**FLIGHT-02:** Takeoff requires enough overhead and forward clearance. While hovering, Forward requests one complete 4 m flight segment along the current heading. Preflight its entire swept envelope, final hover footprint, and a valid landing option. Release prevents the next segment; an accepted clear segment completes its 3.4 s native motion. Ground turns and ground attacks remain unavailable airborne. If a new dynamic obstacle blocks the segment, enter an explicit FlightBrake transition that resolves collision and settles the pitched body into Hover; validate contact-free retargeting or author a Kiln helper transition rather than freezing a pitched flight frame.

**FLIGHT-03:** Before beginning descent, check both-foot support, controller footprint, and the entire descent path. Only the level dock's permitted landing regions qualify. Slopes, water, curbs, barriers, and large props are invalid.

**FLIGHT-04:** Reserve clear landing strips from dynamic-prop placement. If landing is obstructed, remain hovering and show a concise blocked indicator. Before the Landing clip's 0.68 s contact, an unexpected obstruction can enter LandingAbort: collision-check the return path and reverse only the pre-contact descent back to Hover, suppressing impact/audio events during reversal. Validate that reversal visually. After contact begins, finish supported compression/recovery; do not reverse into flight. Maintain a reserved footprint through this phase and let the kinematic envelope push aside loose large props while cosmetic debris is ignored. Do not silently teleport onto a pad.

**FLIGHT-05:** Approaching the envelope edge rejects further flight but always leaves a safe hover/landing option. Reset remains available from every state. The camera stays within a composition envelope that does not reveal unfinished scenery.

## 10. Weapons and controlled destruction

### Aiming and hits

**HIT-01:** The baseline cannons fire along their actual barrel directions. Display a restrained projected firing indicator. The player turns the Jaeger to aim; camera orbit is observation, not free gun aiming.

**HIT-02:** Use named muzzle sockets for flashes, shot origins, trajectories, and sound. Resolve the nearest valid obstruction along the shot. The trace cannot pass through a wall to damage a target selected by the camera.

**HIT-03:** Melee samples the blade's swept volume during an authored active window surrounding each strike. Windows are tuned from reviewed poses; strike timestamps alone are not a full hit volume. Each strike affects each target at most once.

**HIT-04:** Place target faces at the actual exported cannon/blade heights. A low concrete road barrier may need a taller reinforced target section for the current forward muzzle angle. Do not bend shots downward invisibly to make staging work.

### First-release destruction contract

- Crates are initially dynamic and scatter under contact; they need not fracture.
- Melee target separates into 6-10 chunky, solid pieces at its damage threshold. Initial staging: two normal slash hits or one overhead hit. The first combo strike gives visible/material-specific hit feedback; the second causes fracture.
- Concrete break targets separate into 8-12 pieces on cannon damage; a validated overhead strike may also break them.
- Hangar, gantry, dock, seawall, rocks, and terrain remain intact.

The cinematic assigns the first concrete target to cannon fire and the second to the overhead strike, after the melee target has broken. Tune the second target's contact height to blade reach. Do not respawn a target inside a visible shot to manufacture another impact.

**BREAK-01:** Each breakable object has a manifest containing intact asset/root/collider, fragment meshes/local transforms/colliders/masses, accepted damage types, threshold, material category, fragment cap, impulse limits, and reset placement.

**BREAK-02:** Swap intact and broken state atomically: remove intact rendering/collision before activating fragments at the exact composed object/world transforms. A second hit in the same step cannot trigger a second fracture.

**BREAK-03:** Fracture boundaries fit together in the intact volume. Interior faces are solid and shaded as fresh material. Collision hulls do not significantly overlap at spawn. Impulse direction follows the impact, with bounded upward and angular variation.

**BREAK-04:** Maintain a hard cap of 48 active dynamic bodies on mobile and 80 on desktop, including crates. Cosmetic dust/splinters use particle pools. On budget pressure, replace secondary fragments with visual particles; do not drop the principal chunks that explain the break.

**BREAK-05:** Sleeping debris may remain visible. Retire old debris after a minimum visible lifetime, with a short fade when cleanup is necessary; remove its collider at the same time. No invisible collision leftovers or fragment growth after repeated use.

**BREAK-06:** Broken props do not respawn during normal pilot use. Reset restores them. Watch Demo always starts from the intact baseline.

## 11. Rendering: current Three.js and TSL

### Verified version and implementation rule

The official release page identifies **r186**, released September 8, as latest at this spec's verification. Pin `three` to **0.186.0**, use matching addons, ESM, and the lockfile. Check the actual installed package before implementing any API. Review the r185-to-r186 migration notes and the matching tagged source when live documentation and examples differ. [Official r186 release](https://github.com/mrdoob/three.js/releases/tag/r186)

The stack is **Vite + TypeScript + plain Three.js + WebGPURenderer + TSL + Rapier**. R3F is not needed for this interface. All custom scene shaders use node materials/TSL with the current rendering pipeline. [TSL guide](https://github.com/mrdoob/three.js/wiki/Three.js-Shading-Language)

**RENDER-01:** Initialize WebGPURenderer asynchronously and provide a tested WebGL2 backend. Backend and quality tier are independent: a capable WebGL2 desktop can use higher quality; a slow WebGPU phone can use low quality. [WebGPURenderer](https://threejs.org/docs/pages/WebGPURenderer.html)

### Feature choices that improve this scene

| Feature | Application | First-release decision |
| --- | --- | --- |
| SunLight and cascaded shadows | Warm outdoor light, grounded feet, consistent shadows across dock | Preferred desktop lighting candidate; compare against one tightly fitted directional shadow for this compact scene. Mobile uses the cheaper validated setup. |
| SSAONode | Contact shading in armor gaps, under feet, and around equipment | Half-resolution desktop candidate; reduce or disable on mobile. |
| TSL bloom | Reactor, blade edges, muzzle flashes, exhaust | Restrained, thresholded bloom; armor whites and sky must retain detail. |
| TSL water | Slow waves, moving normal detail, Fresnel response, shoreline foam | Required attractive baseline; no fluid simulation. |
| TSL exhaust/trails | Animated jet structure, tapered blade trails, sparks | Required; socket-driven and pooled. |
| Environment lighting | Metal readability and warm/cool separation | Build from the procedural sky/lighting environment; no external HDR required. |
| Low-cost atmospheric fog | Coastal depth and separation of the distant bluff | Required subtle baseline. |
| OITPassNode | Reduce sorting artifacts among overlapping translucent effects | Optional only if observed artifacts justify its extra pass and memory. |
| Volumetric fog, reflective water capture, retroreflective hazard details | Extra depth and surface response | Desktop polish candidates after baseline acceptance, not simultaneous first-pass requirements. |

`SunLight` provides cascaded shadows and requires explicit node-library registration for WebGPURenderer. Configure from the r186 docs rather than assuming DirectionalLight's targeting behavior. [SunLight](https://threejs.org/docs/pages/SunLight.html)

The current `SSAONode` provides depth-aware denoising and adjustable resolution. Evaluate it at half resolution for contact shading; the visual goal is separation, not dark outlines. [SSAONode](https://threejs.org/docs/pages/SSAONode.html)

Use the current TSL bloom addon, and benchmark Dual Kawase bloom only if the pinned release exposes the required API. Existing BloomNode is a documented baseline. [BloomNode](https://threejs.org/docs/pages/BloomNode.html)

OIT has material/blending restrictions and different MSAA support between backends. It is not a universal transparency fix or a mandatory dependency for the baseline. [OITPassNode](https://threejs.org/docs/pages/OITPassNode.html)

**RENDER-02:** Water can use a custom lightweight TSL surface or adapt the official WaterMesh approach. On mobile, prefer sky/environment response and animated normals over another full scene reflection pass. [WaterMesh](https://threejs.org/docs/pages/WaterMesh.html)

**RENDER-03:** Keep custom effects compatible with both backends. Required VFX must not depend on GPU compute. Optional compute effects need an equivalent bounded non-compute path.

**RENDER-04:** Use one coherent tone-mapping/exposure/color-management setup. Avoid double tone mapping in postprocessing and preserve correct linear/sRGB treatment of the embedded PBR maps.

**RENDER-05:** Antialiasing and postprocessing must be chosen as one tested pipeline. Check thin blades, railings, stencil readability, transparent sorting, and fast camera movement. Do not add incompatible legacy passes because they appear in older examples.

**RENDER-06:** Prewarm all required action/effect material variants and render one actual shadowed frame before reporting Ready. Shader compilation alone is not evidence that first-use shadows/effects are warm.

**RENDER-07:** Failure to initialize WebGPU should allow a deliberate WebGL2 retry. If neither backend works, show a useful poster/message and download links. Device loss must stop simulation safely and offer reload/retry.

## 12. VFX and camera response

| Event | Required treatment | Limits |
| --- | --- | --- |
| Foot contact | Small localized dust/grit and weight impulse | One emission per contact; sparse on clean concrete |
| Slash | Tapered cyan trail following both sampled blade ends | Short lifetime; no permanent ribbons while idle |
| Melee impact | Directional sparks, dust for concrete, large-piece break | Only on confirmed hit; never from animation alone |
| Cannon fire | Brief flash at each muzzle, hot core, short shot streak | Fire independently at 0.40/0.67 s in clip time |
| Cannon impact | Spark/dust burst and target fracture impulse | At resolved hit point/normal |
| Takeoff | Jet ignition and ground dust after support release | Exhaust tracks sockets during body pitch |
| Hover/flight | Shaped exhaust and modest shimmer/intensity change | A readable plume; heat-refraction pass optional |
| Landing | Broad dust ring, brief compression emphasis, heavy sound | On contact at 0.68 s; once per landing |
| Test Impact | Short armor spark and controlled recoil cue | Inspector/test action; no health system |

**FX-01:** Use fixed-size pools for particles, projectiles, trails, impact decals, and transient lights. No unbounded scene-object creation per frame.

**FX-02:** Cap transient unshadowed lights; muzzle light should briefly illuminate nearby armor/ground where budget allows. Avoid new shadow maps for flashes.

**FX-03:** Camera response is an additive, damped impulse layered over user/cinematic control. Never replace input with uncontrolled shaking. Include a reduced-motion setting that disables shake and aggressive cinematic movement.

**FX-04:** The follow/orbit camera checks architecture to avoid clipping into walls. Auto-frame the full mech and attack silhouette; flight widens gently. Camera collision must not cause abrupt zoom oscillation.

## 13. Sound production and playback

The user authorized use of their **ElevenLabs API key** for this demo's sounds. Generate offline, review candidates, then ship selected static audio files. Do not make audio-generation requests from the visitor's browser.

The current sound-effects API supports duration control and seamless-loop requests with its v2 sound model. Resolve the exact model and output format when generating, and keep a record. [ElevenLabs sound-effects API](https://elevenlabs.io/docs/api-reference/text-to-sound-effects/convert)

### Initial sound list

| Family | Suggested variants | Direction |
| --- | ---: | --- |
| Heavy footstep | 3 | Hydraulic weight, metal mechanism, concrete grit; no musical impact |
| Servo movement | 2 | Low mechanical movement, restrained high-frequency detail |
| Cannon preparation | 1 | Short mechanical charge/lock |
| Cannon discharge | 2 | Powerful low-mid punch with a controlled tail |
| Blade sweep | 2 | Fast air movement with subtle energized edge |
| Metal/concrete impact | 2 each | Material-specific contact and debris |
| Thruster ignition | 1 | Mechanical ignition into forceful exhaust |
| Thruster sustain | 1 loop | Stable broadband jet with no obvious repeating accent |
| Thruster shutdown | 1 | Short believable decay |
| Landing | 1-2 | Heavy impact, suspension/servo recovery, concrete grit |
| Coastal dock ambience | 1 loop | Quiet wind/water and distant industrial room tone |

Reuse recordings where they fit; this is a small cohesive library, not a large sound-design project. Start with one candidate per family, audition, then generate alternatives only where needed. Procedural synthesis is optional only for a simple cue that clearly sounds good; it is not the default for hero effects.

**AUDIO-01:** Keep generation scripts and prompt/model/duration provenance in the authoring tools. Keep credentials outside source, browser bundles, manifests, and logs. No generation calls are made while writing this spec.

**AUDIO-02:** Trim attack transients, fades, and tails; verify every loop seam. Convert to browser-supported formats and verify decoding on the target browsers. Audio assets should load once and reuse decoded buffers.

**AUDIO-03:** Event timing follows the same animation event schedule as VFX. Sustained thruster volume follows state; stop/fade it on landing, pause, reset, and scene exit.

**AUDIO-04:** Positional attenuation and mix levels make nearby impacts powerful without masking all other sounds. Use small pitch/gain variation for repeated samples, voice limits, and a limiter or conservative headroom. No clipping, sudden full-volume stacking, or unintended silence at loop joins.

**AUDIO-05:** Require listening on headphones and ordinary speakers/phone audio. File validity or loudness statistics are not substitutes for hearing the sounds. Record the applicable generation/license provenance without inventing a redistribution license.

## 14. Reset, pause, and lifecycle

**RESET-01:** One Reset restores the mech pose/world transform, camera, intact targets, crate placements, physics velocities, broken flags, event deduplication, particle/decal/trail pools, projectiles, sound loops, input queues, and cinematic time.

**RESET-02:** Reset does not reload the entire page. It leaves counts at the recorded baseline. Shared loaded assets stay cached; per-instance simulation/effect state is reset.

**RESET-03:** Pause freezes animation, physics, effects, and timeline consistently and pauses/fades audio. Resume does not consume wall-clock time spent paused. Downloads and UI remain usable.

**RESET-04:** Hidden tabs clear held inputs and pause. On return, show a safe paused state. Dispose instance resources and listeners when recreating renderer/world; avoid duplicate loops and input handlers.

## 15. Performance, quality tiers, and accessibility

These are initial engineering targets and become release gates on the named reference devices. Select and record the available PC, a midrange Android phone, and an iPhone before the main environment pass. A desktop resize or mobile emulation is not evidence of real-phone performance. Device coverage that cannot be exercised stays explicitly untested; do not generalize a fast workstation result to all phones.

| Budget | Desktop target | Mobile target |
| --- | --- | --- |
| Smooth action playback | >=58 fps average at 1080p; p95 frame interval <=20 ms, p99 <=25 ms | >=29 fps average; p95 <=40 ms, p99 <=50 ms on recorded Android/iPhone |
| Cold action after Ready | No action-triggered frame >50 ms | No action-triggered frame >50 ms |
| Sustained frame pacing | Investigate every >50 ms foreground hitch; no recurring action/reset hitch | Investigate every >50 ms foreground hitch; no recurring action/reset hitch |
| Drawing-buffer pixel ratio | Cap 1.5 initially | Cap 1.25; adaptive down to 0.75 |
| Primary visible geometry | <=200k triangles typical | <=200k, reduce scenery where necessary |
| Main scene color draw submissions | <=220 target after runtime optimization | <=220 target after runtime optimization |
| Total draw submissions including shadows/postprocessing | <=650 target | <=450 target |
| Estimated decoded texture allocation | <=128 MiB | <=64 MiB; report render targets separately |
| Active particles | <=512 | <=128 |
| Dynamic bodies including crates/chunks | <=80 | <=48 |
| Simultaneous audio voices | <=16 | <=8 |
| Initial compressed transfer | <=15 MB target including runtime/physics/scene/audio | Same; defer optional high-quality assets |

**PERF-01:** Profile the hero first: 470 meshes means triangle count is not the only concern. Merge compatible rigid meshes by material under the same animated parent, or use an equally verified batching strategy. Preserve every animated node, pivot, socket, and clip. Never merge across independently moving parts.

**PERF-02:** Keep the canonical download unchanged. A derived runtime asset MUST record input/output hashes and optimization steps and pass motion/material comparisons against v4.

**PERF-03:** Instance repeated scenery; share materials/textures; keep static collider counts modest. Avoid costly transparent overdraw and unnecessary shadow casters. Measure all passes, not only the main color render.

**PERF-04:** Auto quality adjusts resolution, AO, water reflections, particle counts, and shadows with hysteresis. It must not repeatedly rebuild shaders during combat or change action timing/physics semantics. Provide Auto/High/Low and persist the selection.

**PERF-05:** Benchmark cold first interaction and a repeatable 60-second worst-case action sequence, plus a 10-minute mobile soak. Report device, browser, backend, tier, viewport, frame-time distribution, and memory/body/effect counts. If a target is missed, document the measured compromise; do not silently claim it passed.

### Required optimization work

**PERF-06:** Profile and optimize the Jaeger before polishing the environment. Capture a baseline of mesh submissions, render passes, CPU update cost, and GPU time where the backend exposes it. The existing GLB's small download and modest triangle count do not establish runtime efficiency. Retain before/after evidence for the chosen batching strategy.

Read-only analysis of the current GLB found 470 one-primitive mesh instances, 199 shared mesh definitions, 14 opaque materials, and 36 animation-targeted nodes. Grouping by direct parent/material gives 214 potential groups; grouping by nearest animated ancestor/material gives 137 potential groups (139 when attribute layouts are also separated). These are static grouping estimates, not implemented merges or measured frame times. They identify a practical optimization path: bake static intermediate transforms into merged geometry while retaining the complete rig/socket node tree. Any runtime-driven joint must also form a grouping boundary. Validate the current 16 clips and every planned overlay before accepting the derivative. Report main-color and shadow submissions separately so multi-pass costs are visible.

If that approach misses the measured budget, evaluate a derived rigid-skin representation: one joint influence per vertex, grouped by material, with equivalent animation transforms. This is an optional optimization experiment, not a required new authoring workflow. It must retain the source rig and pass normal, material, bound, socket, all-clip, and backend checks before replacing the runtime derivative. Do not describe theoretical material-group counts as achieved performance.

**PERF-07:** The optimized runtime artifact must preserve silhouettes, material boundaries, UVs, pivots, socket transforms, and all clips. Validate selected vertices/socket world transforms and reviewed poses against the canonical GLB. An optimization is not accepted if hands, cannons, fracture origins, or animation targets break. Retain the original source/download and generate the runtime derivative reproducibly.

**PERF-08:** Remove avoidable work from the hot loop: reuse vectors/matrices and event buffers; pool effects and physics fragments; update UI only when state changes; cache rig/socket lookups; limit ray/shape queries to relevant collision groups; avoid geometry rebuilding, JSON parsing, audio decoding, DOM layout reads, or shader creation during attacks. Profile garbage-collection pauses instead of assuming object pooling solved them.

**PERF-09:** First-use preparation covers cannon flash/impact, each blade trail/material variant, target fracture/chunk materials, exhaust, landing particles, required postprocessing, shadow rendering, and decoded audio. Exercise them in a hidden warm-up state, clear that state, and only then expose Ready. Warm-up is bounded and visible as loading progress; it cannot stall indefinitely or play audio without a gesture.

**PERF-10:** Destruction fragments and collision shapes are authored/loaded in advance. On a hit, activate pooled state and cached shapes; do not run mesh booleans, fracture algorithms, texture generation, or large asset loads. If a physics allocation is unavoidable, measure its first activation and eliminate a visible hitch before release.

**PERF-11:** Every quality tier has explicit geometry, shadow, render-target, particle, body, and voice limits. Changes use sustained measurements and hysteresis rather than oscillating each second. Prefer resolution reduction over repeatedly compiling new materials. Prepare tier variants before switching and avoid moving the player or changing interaction outcomes during a quality change.

**PERF-12:** Limit work to visible/relevant content. Batch or instance static props, use measured distance culling/LOD for coastal dressing, reduce shadow casters and shadow updates, and keep transparent effect coverage small. Any instancing/batching change must be measured on WebGPU and WebGL2; fewer JavaScript objects alone are not sufficient evidence.

**PERF-13:** Keep Kiln and ElevenLabs generation tooling out of the visitor bundle. Report compressed network transfer, parse/init time, asset decode/upload time, warm-up time, and time to Ready separately. Serve optional downloads and high-quality assets on demand. Verify caching, relative URLs, and WASM/audio content delivery in the production build.

**PERF-14:** Use repeatable performance captures: fixed initial scene, fixed camera route, same action sequence, declared quality, and warm/cold distinction. Report average fps, p50/p95/p99 frame intervals, longest frames and their triggers, draw submissions by pass, body/particle/voice peaks, and the backend actually used. Do not report CPU scheduling time as GPU render time; use GPU timestamps only when supported and label unavailable measurements.

**PERF-15:** Repeated Reset must return allocations/counts to the expected baseline without forcing a page reload. Run ten complete destruction/reset cycles and a ten-minute sustained session; memory/resource counts must plateau. No accumulating event listeners, animation mixers, physics worlds, sound sources, render targets, or shader variants.

**PERF-16:** A scene that looks good only after the first shot, or only while stationary, fails the performance requirement. Cold cannon fire, cold slash, cold boost/landing, simultaneous debris/effects, and reset immediately after destruction are explicit acceptance cases. Separate scene-caused hitches from documented tab switches, OS interruptions, and measurement tooling; do not erase unexplained outliers.

No first action may trigger an asset fetch, audio decode, physics initialization, shader compilation, or bulk fragment construction. A repeatable application-caused action/reset frame over 50 ms after Ready fails on either reference platform, even if average fps meets its target.

**PERF-17:** If a reference device misses its gate, simplify expensive lighting/postprocessing/scenery or improve batching before declaring completion. If a proposed numerical target proves inappropriate for available hardware, record the device data and obtain agreement on the revised target; do not silently lower it. Public copy must name the tested conditions and avoid universal FPS claims.

**PERF-18:** Use the editable profile for source/review packages and the runtime profile for the in-scene GLB when the separate export-profile change is qualified. Runtime GLB animation and rendering MUST work with its sidecar absent. A small versioned provenance record points to a relative metadata filename and its SHA-256; authoring/review metadata stays outside the hot-load GLB. Preserve unknown application extras, rig/socket data and native animation. Record the exact engine commit used. An open PR is not a released capability and MUST NOT be merged automatically for the demo.

**PERF-19:** Separate size work from rendering work. Removing duplicate metadata reduces transfer and JSON parsing; compression reduces storage/transfer and may add decode cost; neither inherently reduces draws. First batch compatible geometry under retained animation and runtime-control boundaries. Then consider shared texture atlases, conservative reduction of excessive tiny-cylinder/ring segments, or LOD only where measurements justify it. Match silhouettes and important close-ups after every step. Defer meshopt/Draco/KTX2 until an actual transfer/decode/memory comparison shows a net benefit.

**ACCESS-01:** Keyboard-focusable menus/buttons, visible focus, readable text, 48 px touch targets, clear disabled/busy states, and no color-only action feedback. Honor reduced motion, provide mute, and do not require audio to understand actions.

## 16. Repository and data layout

Future repository root: `C:/Users/Mattm/X/jaeger-demo`. This spec currently lives with the source asset and is intended to be copied into the new repository when implementation begins.

```text
jaeger-demo/
  .github/workflows/pages.yml
  README.md
  package.json
  package-lock.json
  index.html
  docs/
    scene-spec.md
    validation.md
    asset-provenance.md
  authoring/
    jaeger/                 # copied source modules and motion contract
    environment/            # Kiln source modules, fixed seeds, build config
    audio/                  # generation prompts/manifests, no credentials
  scripts/
    build-assets.*
    verify-assets.*
    generate-sounds.*
  public/
    version.json             # release commit and shipped asset hashes
    assets/                 # runtime GLBs, textures, audio
    downloads/              # canonical GLB and source ZIP
    preview/                # poster/share image
  src/
    app.ts
    renderer/               # WebGPU/backend/TSL/postprocessing/quality
    scene/                  # loading, layout, terrain/water integration
    character/              # animation state machine, root motion, sockets
    input/                  # keyboard/touch/camera intentions
    physics/                # fixed-step world, collision groups, destruction
    effects/                # pooled VFX and animation event consumers
    audio/                  # static asset loading, positional playback, mix
    demo/                   # cinematic timeline and scene reset
    ui/                     # controls, inspector, settings, downloads
    data/                   # typed asset/action/fracture/layout manifests
  tests/
```

**TECH-01:** No backend is required to view the demo. Bundle/load assets from the same static origin; support a configurable base path. Physics WASM initialization and asset failures are explicit loading states.

**TECH-02:** Pin exact dependency versions at implementation start, including Three.js 0.186.0 and a verified compatible Rapier package. Build tooling MUST not silently mix installed Three.js with addons from a different CDN revision. Rapier requires asynchronous WASM initialization. [Rapier setup](https://rapier.rs/docs/user_guides/javascript/getting_started_js/)

**TECH-03:** Keep one simulation clock and typed action events. Rendering, audio, VFX, and damage consume those events; UI expresses intentions. Cinematic playback sends the same intentions rather than a separate damage/animation implementation.

**TECH-04:** Asset manifests contain stable IDs, relative file paths, SHA-256, Kiln source/revision/runtime identity, units, bounds, materials, sockets, collider proxies, fracture variants, and attribution. Audio records contain prompt/model/format provenance without secrets.

**TECH-05:** Publish-ready files include canonical GLB, editable Kiln source package, README with runnable commands, credits, license information appropriate to each included asset, and a poster. Download responses must produce the named files rather than a routed HTML page.

**TECH-06:** Start implementation in the separate local folder `C:/Users/Mattm/X/jaeger-demo`, initialize its own repository, and copy this spec/provenance rather than using the Kiln engine checkout as a demo. The intended public repository is `jaeger-demo`; GitHub Pages is the selected host. The current request updates the plan and supplies an execution goal. Local implementation and eventual publication are separate milestones; complete local playtesting before publishing the accepted build.

**TECH-07:** Provide locked dependencies and working `npm ci`, `npm run dev`, `npm run build`, `npm run preview`, and relevant validation commands. Leave the actual production preview running and open its verified URL for the owner's playtest. Provide a concise controls guide and known-issues list. Do not substitute an asset viewer or recorded cinematic for the playable application.

**TECH-08:** Configure and test Vite's project-site base path `/jaeger-demo/`. Resolve runtime GLBs, sidecars, physics WASM, audio, posters and downloads through that base, including the WebGL2 fallback path. A local production preview must exercise the same subpath before release. [Vite GitHub Pages deployment](https://vite.dev/guide/static-deploy.html#github-pages)

**TECH-09:** Build and publish the accepted commit through a GitHub Pages Actions workflow, with explicit build/deploy dependency and the required Pages environment/permissions. Check current official action versions at implementation time and pin them. The public bundle contains static generated audio and assets, never Kiln/ElevenLabs credentials or a dependency on local authoring servers. [GitHub Pages custom workflows](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages)

**TECH-10:** Emit a release manifest containing the source commit, dependency versions and shipped asset hashes. After publication, verify the real site reports that exact commit, fetch and hash the actual GLB/downloads, and run the watch/control/action/reset/download flow at the published `/jaeger-demo/` URL. A green deployment job alone is insufficient proof that the expected scene is live.

## 17. Build sequence and completion gates

### Gate 0: Runtime asset qualification

- Create the separate local demo repository and copy the canonical v4 source/artifact/proof packet. Pin the renderer and record engine/exporter identity.
- Build a small local harness that loads the real GLB, plays/scrubs all sixteen clips, overlays socket markers, and records baseline submissions and frame intervals on WebGPU and forced WebGL2.
- Produce a reproducible runtime derivative: qualified metadata export plus animation-aware mesh batching. Preserve application extras, animated/runtime-controlled pivots and socket transforms. Keep canonical GLB/source downloads.
- Initial hero-only target: no more than 160 main-color submissions, leaving headroom within the complete-scene 220 target. This is a target, not a count already achieved. Keep the full-scene frame-time requirements authoritative and explicitly record any justified strategy/target change.
- Compare all clip targets/keyframes, selected posed vertices and every socket; review front/rear/angled/attack/flight views in the intended renderer. Record GPU timings only when available, and distinguish CPU from GPU time.
- Exit: a measured, visually equivalent runtime hero with a reproducible build, working downloads and honest backend/device evidence. If it fails, address batching or expensive geometry before environment polish. Full-game systems, a creature, and Tier 2 dogfooding are not part of this gate.

### Gate 1: Technical proof using the current hero

- Initialize pinned renderer and physics; load v4; verify all clips and texture maps.
- Test WebGPU and forced WebGL2 with one representative TSL effect.
- Establish root-motion ownership, start/stop, quarter turns, low flight, and cannon direction.
- Accept forward stopping across all release phases, completed-quarter-turn input semantics, FlightBrake, and pre-contact LandingAbort before extending the scene.
- Reuse the qualified Gate 0 runtime hero and verify new animation overlays do not invalidate its batching boundaries.
- Measure baseline frame pacing, cold actions, and the proposed runtime batching on the actual renderer paths before adding scene detail.
- Exit: no snapping, double translation, invisible material failure, or wrong asset revision; a documented performance envelope exists for the hero and effects.

### Gate 2: Kiln environment and layout

- Author the small asset kit and uneven scenic terrain; save provenance and fixed seeds.
- Block out the flat action corridor, real-height targets, safe boundaries, and landing strips.
- Review warm/cool lighting, scale cues, full orbit, and silhouette separation.
- Exit: complete environment with useful collision and no unsupported scenic walking.

### Gate 3: Interaction and destruction

- Implement crate pushing, target slash fracture, and cannon barrier fracture.
- Validate event deduplication, physical caps, landing obstruction handling, and Reset.
- Exit: the three interactions can be repeated ten times without accumulating state.

### Gate 4: Presentation and sound

- Generate/audition the concise ElevenLabs set; attach sound and VFX to validated events.
- Add TSL water, readable bloom, contact shading, flight/landing response, and the cinematic.
- Exit: every major action has coordinated visuals/sound and a clear camera composition.

### Gate 5: Complete local playtest candidate

- Finish touch UI, inspection, accessibility options, quality tiers, downloads, and credits.
- Run the acceptance matrix below on real devices and both renderer backends where available.
- Exercise the production build under `/jaeger-demo/`, including WASM/audio and both downloadable GLBs plus source ZIP; leave it running for local playtesting.
- Exit: the owner can actually watch, drive, slash, fire, boost/land, break props, reset, inspect and download in the local production build. Supply URL, controls, tested device/backend data and any remaining issues. Fix observed blockers before release.

### Gate 6: GitHub repository and Pages release

- After the local playtest milestone and release authorization, create the intended `jaeger-demo` GitHub repository without altering an existing unrelated repository. Include source, locked builds, authorship/credits, license information, the scene spec and validation evidence.
- Configure GitHub Pages via Actions, publish the accepted release commit, and retain the build identity/asset manifest.
- Verify actual site identity, base-path asset requests, renderer fallback, audio activation, the three interactions/reset, and independent downloads on the live URL. Record any unavailable real-device coverage explicitly.
- Exit: provide the repository URL, working Pages URL, exact verified commit, downloadable model/source links, and release evidence. Do not merge the separate Kiln engine PR as part of this gate without a new instruction.

### Scope control

Core blockers are the current hero looking correct, usable control, motion continuity, valid collisions, three destruction interactions, coherent VFX/audio, mobile usability, reset, and downloads. Simplify environmental dressing, reflection passes, volumetric effects, additional sound variants, and optional pylon toppling before expanding the schedule. Preserve a written list of any incomplete MUST requirements. Do not label a partial cinematic-only prototype as the finished interactive release.

## 18. Acceptance matrix

Record pass/fail and evidence against these IDs in the future `docs/validation.md`.

| ID | Test | Passing evidence |
| --- | --- | --- |
| QA-01 | Clean install and production build | Documented commands succeed from a fresh local checkout with locked dependencies. |
| QA-02 | Input identity and downloads | v4 hash verified; canonical download opens independently with all 16 clips and eight images; source ZIP is complete. |
| QA-03 | Asset authorship | Every solid scene asset and fragment family has Kiln source/runtime/hash provenance; exceptions match section 2. |
| QA-04 | Visual review | Hero, action, rear/oblique, and flight screenshots preserve silhouette/finish and show no return of repaired surface artifacts. |
| QA-05 | Terrain and scale | Flat playable deck plus visible three-dimensional coast; no cracks at seams; truck/door/rail scale consistent. |
| QA-06 | All animation clips | Every named clip plays/scrubs independently without unresolved tracks; inspector cannot damage props while scrubbing. |
| QA-07 | Root motion | Ten walks in an isolated test lane travel approximately 32 m; four same-direction turns return heading; repeated hover does not climb; full flight chain has no snap. |
| QA-08 | Contact and input | Start/release/blocked stop have no persistent foot skating, ground sinking, or indefinite walking; stop latency recorded against the 0.8 s target. |
| QA-09 | State/queue stress | Mash actions, release input, pause/resume, and switch modes; no illegal airborne melee, backlog, duplicate firing, or interrupted landing compression. |
| QA-10 | Collision | Walk into each substantial obstacle and boundary; turn nearby; no pass-through. Weapon traces hit the first valid obstruction. |
| QA-11 | Flight safety | Test every boundary and invalid landing condition; no water/prop/slope landing, ascent stacking, or silent teleport. |
| QA-12 | Destruction | Crates scatter, target splits, barrier crumbles; intact collision disappears; pieces have interiors and bounded impulses. |
| QA-13 | Event correctness | At 30/60/variable fps and injected stalls, each intended shot/strike/contact fires once; missed targets do not produce contact effects. |
| QA-14 | Reset repetition | Ten destruction/reset cycles restore baseline object/body/effect/audio counts and placements. |
| QA-15 | Mobile interaction | Real Android and iPhone runs, portrait/landscape, simultaneous pointers, cancel/blur/resume, readable controls and working downloads. Record unavailable hardware as untested. |
| QA-16 | Renderer compatibility | Native WebGPU and forced WebGL2 screenshots/interaction runs; feature reductions are documented; no required effect disappears silently. |
| QA-17 | Cold/steady performance | First action after Ready, 60-second worst-case sequence, and 10-minute soak measured with device/backend/tier and frame-time results. |
| QA-18 | Audio audition | Headphones and speakers/phone: clean loops, synced actions, no clipping/stacking; mute and pause/reset reliable. |
| QA-19 | Cinematic | Complete 35-45 s guided sequence with readable actions, intact restart, no hard mid-shot reset, and working handoff to control. |
| QA-20 | Accessibility/failure states | Keyboard menus, focus, reduced motion, mute, loading failure/retry, unsupported renderer, and device-loss handling reviewed. |
| QA-21 | Runtime optimization equivalence | Canonical and derived GLBs retain matching clips, pivots, socket paths, material appearance, and reviewed poses; before/after submissions and frame times recorded. |
| QA-22 | Frame stability and resource lifetime | Cold action thresholds and p95/p99 gates met on named devices; repeated fracture/reset and sustained operation show bounded allocations and no recurring stall. |
| QA-23 | Local playtest handoff | Production preview is running at the tested project subpath; owner receives actual URL, controls, known issues, and can complete the interactive flow. |
| QA-24 | Runtime profile independence | Runtime GLB loads with all clips/materials/sockets when the sidecar is absent; when present, provenance/version/hash resolve to the expected metadata. |
| QA-25 | Pages paths and release identity | Published source commit matches the release manifest; model/source hashes and real `/jaeger-demo/` asset, WASM, audio and download responses are verified. |
| QA-26 | Live release flow | Watch/control, slash/fire/boost/land, destruction/reset and independent downloads succeed on the deployed site; tested devices/backends are named. |

Required automated tests should focus on behavior with real failure modes: root accumulation, legal state transitions, event deduplication, fracture/reset lifecycle, manifest integrity, and time-step handling. Use actual browser runs for rendering, audio, touch, and performance; unit tests cannot establish those qualities.

## 19. Definition of done

- All first-release MUST requirements have passing evidence or an explicit user-approved scope change.
- One complete Kiln-authored environment surrounds the current Jaeger, including actual uneven coastal terrain.
- PC/mobile visitors can watch, control, inspect all 16 animations, trigger the three physics interactions, reset, and download.
- The rig, collisions, VFX, sound, and camera remain coordinated through full action sequences.
- The production build has been exercised locally with recorded renderer/device coverage.
- The named reference-device performance gates pass, including first-use actions, frame pacing, destruction/reset, and sustained operation; any revised target is explicitly agreed and recorded.
- Source, asset/audio provenance, limitations, and runnable build instructions are included.
- The owner has seen the real scene and heard its sound mix; numerical checks do not substitute for that artistic review.
- Local completion and public completion are reported separately: Gate 5 supplies the playable local build; Gate 6 supplies the verified GitHub repository and live Pages release after authorization.

## 20. Implementation defaults and remaining evidence

No further design questionnaire is needed to start. Defaults are the coastal dock, Kiln-generated solids/terrain, Three.js r186/TSL, plain TypeScript UI, Rapier, ElevenLabs effects, forward/quarter-turn controls, low boost flight, three controlled destruction interactions, and one short cinematic.

Implementation must still establish: exact optimized draw-call count; accepted stop/turn transitions; the available real-phone test devices; final environment seeds/layout; final audio takes and recorded generation usage; and the actual GitHub repository/Pages URLs and release identity. These are tracked implementation outcomes, not claims that the scene already exists.

Copy-ready execution goal: [implementation-goal.md](implementation-goal.md).
